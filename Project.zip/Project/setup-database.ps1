#!/usr/bin/env pwsh
# Database Setup Script for Online Shopping Application
# Run this script in PowerShell to set up the database

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Online Shopping App - Database Setup" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# Set project directory
$projectPath = "C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp"

# Check if directory exists
if (-not (Test-Path $projectPath)) {
    Write-Host "ERROR: Project directory not found: $projectPath" -ForegroundColor Red
    Write-Host "Please update the `$projectPath variable in this script." -ForegroundColor Yellow
    exit 1
}

# Navigate to project directory
Write-Host "Navigating to project directory..." -ForegroundColor Yellow
Set-Location $projectPath

# Check if .csproj file exists
if (-not (Test-Path "OnlineShoppingApp.csproj")) {
    Write-Host "ERROR: OnlineShoppingApp.csproj not found in current directory" -ForegroundColor Red
    exit 1
}

Write-Host "? Project found" -ForegroundColor Green
Write-Host ""

# Step 1: Check LocalDB status
Write-Host "Step 1: Checking LocalDB status..." -ForegroundColor Yellow
try {
    $localDbInfo = sqllocaldb info MSSQLLocalDB 2>&1
    if ($localDbInfo -match "State: Running") {
      Write-Host "? LocalDB is already running" -ForegroundColor Green
    } else {
   Write-Host "Starting LocalDB..." -ForegroundColor Yellow
        sqllocaldb start MSSQLLocalDB
    Start-Sleep -Seconds 2
  Write-Host "? LocalDB started" -ForegroundColor Green
    }
} catch {
    Write-Host "WARNING: Could not check LocalDB status" -ForegroundColor Yellow
    Write-Host "If this fails, you may need to install SQL Server Express LocalDB" -ForegroundColor Yellow
}
Write-Host ""

# Step 2: Check if EF Core tools are installed
Write-Host "Step 2: Checking EF Core tools..." -ForegroundColor Yellow
$efInstalled = dotnet tool list -g | Select-String "dotnet-ef"
if (-not $efInstalled) {
    Write-Host "Installing EF Core tools globally..." -ForegroundColor Yellow
    dotnet tool install --global dotnet-ef
    Write-Host "? EF Core tools installed" -ForegroundColor Green
} else {
    Write-Host "? EF Core tools already installed" -ForegroundColor Green
}
Write-Host ""

# Step 3: Drop existing database (optional)
Write-Host "Step 3: Database cleanup..." -ForegroundColor Yellow
$dropDb = Read-Host "Do you want to drop the existing database? (y/N)"
if ($dropDb -eq "y" -or $dropDb -eq "Y") {
    Write-Host "Dropping database..." -ForegroundColor Yellow
    dotnet ef database drop --force
    Write-Host "? Database dropped" -ForegroundColor Green
} else {
    Write-Host "Skipping database drop" -ForegroundColor Cyan
}
Write-Host ""

# Step 4: Remove old migrations (optional)
Write-Host "Step 4: Migration cleanup..." -ForegroundColor Yellow
if (Test-Path "Migrations") {
    $removeMigrations = Read-Host "Do you want to remove existing migrations? (y/N)"
    if ($removeMigrations -eq "y" -or $removeMigrations -eq "Y") {
 Write-Host "Removing migrations..." -ForegroundColor Yellow
      Remove-Item -Path "Migrations" -Recurse -Force
        Write-Host "? Migrations removed" -ForegroundColor Green
    } else {
        Write-Host "Keeping existing migrations" -ForegroundColor Cyan
    }
} else {
    Write-Host "No existing migrations found" -ForegroundColor Cyan
}
Write-Host ""

# Step 5: Create new migration
Write-Host "Step 5: Creating migration..." -ForegroundColor Yellow
$migrationExists = Test-Path "Migrations"
if (-not $migrationExists) {
    Write-Host "Creating InitialCreate migration..." -ForegroundColor Yellow
    dotnet ef migrations add InitialCreate
    if ($LASTEXITCODE -eq 0) {
        Write-Host "? Migration created successfully" -ForegroundColor Green
    } else {
        Write-Host "ERROR: Failed to create migration" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "? Migration already exists" -ForegroundColor Green
}
Write-Host ""

# Step 6: Update database
Write-Host "Step 6: Updating database..." -ForegroundColor Yellow
Write-Host "This will create the database and seed data..." -ForegroundColor Cyan
dotnet ef database update --verbose

if ($LASTEXITCODE -eq 0) {
    Write-Host "? Database updated successfully" -ForegroundColor Green
} else {
    Write-Host "ERROR: Failed to update database" -ForegroundColor Red
    Write-Host "Check the error messages above for details" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Step 7: Verify database
Write-Host "Step 7: Verifying database..." -ForegroundColor Yellow
$connectionString = "(localdb)\MSSQLLocalDB"
try {
    $query = "SELECT COUNT(*) AS ProductCount FROM OnlineShoppingDb.dbo.Products"
    $result = sqlcmd -S $connectionString -Q $query -h -1 -W 2>&1
    
  if ($result -match "\d+") {
        $count = [int]($result -replace '\s','')
        if ($count -eq 10) {
            Write-Host "? Database verified: $count products found (Expected: 10)" -ForegroundColor Green
        } else {
   Write-Host "WARNING: Found $count products (Expected: 10)" -ForegroundColor Yellow
      }
    }
} catch {
    Write-Host "Could not verify database contents" -ForegroundColor Yellow
}
Write-Host ""

# Step 8: Display connection info
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Setup Complete!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Database Information:" -ForegroundColor White
Write-Host "  Database Name: OnlineShoppingDb" -ForegroundColor Cyan
Write-Host "  Server: (localdb)\MSSQLLocalDB" -ForegroundColor Cyan
Write-Host "  Location: LocalDB instance" -ForegroundColor Cyan
Write-Host ""
Write-Host "To connect in SSMS:" -ForegroundColor Yellow
Write-Host "  1. Open SQL Server Management Studio" -ForegroundColor White
Write-Host "  2. Server name: (localdb)\MSSQLLocalDB" -ForegroundColor Cyan
Write-Host "  3. Authentication: Windows Authentication" -ForegroundColor White
Write-Host "  4. Click Connect" -ForegroundColor White
Write-Host ""
Write-Host "To run the application:" -ForegroundColor Yellow
Write-Host "  1. Open the solution in Visual Studio" -ForegroundColor White
Write-Host "  2. Press F5 to run" -ForegroundColor White
Write-Host ""
Write-Host "Database Tables Created:" -ForegroundColor Yellow
Write-Host "  ? Products (10 items seeded)" -ForegroundColor Green
Write-Host "  ? CartItems" -ForegroundColor Green
Write-Host "  ? __EFMigrationsHistory" -ForegroundColor Green
Write-Host ""

# Optional: Open SSMS
$openSSMS = Read-Host "Do you want to open SQL Server Management Studio? (y/N)"
if ($openSSMS -eq "y" -or $openSSMS -eq "Y") {
    Write-Host "Opening SSMS..." -ForegroundColor Yellow
    Start-Process "ssms.exe" -ArgumentList "-S `"(localdb)\MSSQLLocalDB`""
}

Write-Host ""
Write-Host "Setup script completed successfully!" -ForegroundColor Green
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
