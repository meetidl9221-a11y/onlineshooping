# Online Shopping Application

A fully functional e-commerce web application built with ASP.NET Core MVC (.NET 8) demonstrating clean code principles, design patterns, comprehensive error handling, and excellent user experience.

## ?? Project Overview

This application fulfills all requirements for an online shopping platform with the following features:
- Product listing with detailed information
- Shopping cart functionality
- Automatic discount application based on cart value
- Purchase summary and checkout
- Responsive UI with Bootstrap 5
- Clean architecture with service layer pattern

## ??? Architecture & Design Patterns

### Design Patterns Implemented
1. **Repository Pattern**: Service layer abstracts data access logic
2. **Dependency Injection**: All services are injected via constructor
3. **Service Layer Pattern**: Business logic separated from controllers
4. **ViewModel Pattern**: Data transfer between controllers and views

### Project Structure
```
OnlineShoppingApp/
??? Controllers/    # MVC Controllers
?   ??? ProductController.cs
?   ??? CartController.cs
?   ??? HomeController.cs
??? Services/          # Business Logic Layer
?   ??? IProductService.cs
?   ??? ProductService.cs
?   ??? ICartService.cs
?   ??? CartService.cs
??? Models/    # Domain Models
? ??? Product.cs
?   ??? CartItem.cs
?   ??? ViewModels/
??? Data/    # Database Context
?   ??? ApplicationDbContext.cs
??? Views/  # Razor Views
?   ??? Product/
?   ??? Cart/
?   ??? Shared/
??? Migrations/           # EF Core Migrations
```

## ? Features

### 1. Product Management
- **Product Listing**: Display all products with filtering by category
- **Product Details**: Detailed view of individual products
- **Product Attributes**:
  - Name
  - Description
  - Price
  - Discount percentage
  - Category
  - Image URL
  - Availability status

### 2. Shopping Cart
- **Add to Cart**: Add products with specified quantity
- **Remove from Cart**: Remove individual items
- **Update Quantity**: Modify item quantities dynamically
- **Session-based Cart**: Cart persists during user session

### 3. Discount Logic
- **Automatic Discount Application**:
  - Discount threshold: **$5,000**
  - Discounts only apply when cart subtotal ? $5,000
  - Below threshold: No discounts applied
  - Above threshold: All product discounts automatically applied
- **Visual Feedback**: 
  - Progress bar showing discount eligibility
  - Clear messaging about amount needed to unlock discounts

### 4. Purchase Summary
- **Order Details**: Complete breakdown of purchase
- **Order ID Generation**: Unique order identifier
- **Timestamp**: Purchase date and time
- **Discount Summary**: Shows savings when applicable
- **Final Total**: Grand total with all calculations

## ?? Technology Stack

- **Framework**: ASP.NET Core MVC 8.0
- **Database**: SQL Server (LocalDB)
- **ORM**: Entity Framework Core 8.0
- **Frontend**: 
  - Bootstrap 5
  - Font Awesome 6.4
  - Razor Views
- **Session Management**: In-Memory Cache
- **Logging**: Built-in ASP.NET Core Logging

## ?? Database Configuration

### Connection String (appsettings.json)
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\MSSQLLocalDB;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

### Database Schema

**Products Table**:
- ProductId (PK, Identity)
- Name (nvarchar(100), Required)
- Description (nvarchar(500), Required)
- Price (decimal(18,2), Required)
- Discount (decimal(5,2), 0-100%)
- Category (nvarchar(50))
- ImageUrl (nvarchar(200))
- IsAvailable (bit)

**CartItems Table**:
- CartItemId (PK, Identity)
- SessionId (nvarchar(max), Required)
- ProductId (FK to Products)
- Quantity (int, Required)
- Price (decimal(18,2))
- Discount (decimal(5,2))
- AddedDate (datetime2)

## ?? Setup Instructions

### Prerequisites
- Visual Studio 2022 or later
- .NET 8 SDK
- SQL Server Express LocalDB

### Quick Setup (Automated)

#### Option 1: Run Setup Script (Easiest)
**Double-click**: `setup-database.bat`

This will automatically:
- ? Start LocalDB
- ? Create database
- ? Run migrations
- ? Seed 10 products
- ? Verify setup

#### Option 2: PowerShell Script
```powershell
.\setup-database.ps1
```

### Manual Setup

1. **Clone/Extract the Project**
   ```
   Navigate to: C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp
   ```

2. **Open Solution**
   ```
   Open OnlineShoppingApp.sln in Visual Studio
   ```

3. **Restore NuGet Packages**
   ```
   Visual Studio will automatically restore packages
   Or run: dotnet restore
   ```

4. **Create Database**
   
   **Using Package Manager Console (Recommended)**:
   ```powershell
   Update-Database
   ```
   
   **Using .NET CLI**:
   ```bash
   cd OnlineShoppingApp
   dotnet ef database update
   ```

5. **Run the Application**
   - Press F5 in Visual Studio
   - Or run: `dotnet run`
   - Application will open at: https://localhost:7xxx

### ?? Connect to Database in SSMS

After running the setup, connect to the database in SQL Server Management Studio:

1. Open **SQL Server Management Studio (SSMS)**
2. **Server name**: `(localdb)\MSSQLLocalDB`
3. **Authentication**: Windows Authentication
4. Click **Connect**
5. Expand **Databases** ? Find **OnlineShoppingDb**

**Important**: Use exactly `(localdb)\MSSQLLocalDB` (with parentheses and backslash)

**Need help?** See `SSMS_CONNECTION_GUIDE.md` for detailed connection instructions.

### ?? Database Troubleshooting

If database is not visible in SSMS or you have connection issues:

1. **Run Database Setup**: Double-click `setup-database.bat`
2. **See Detailed Guide**: Check `DATABASE_SETUP_FIX.md`
3. **Quick Reference**: See `SSMS_CONNECTION_GUIDE.md`

**Common Issues**:
- LocalDB not running ? Run `sqllocaldb start MSSQLLocalDB`
- Database not visible ? Make sure you're connected to `(localdb)\MSSQLLocalDB`
- Migration errors ? Run `dotnet ef database update --force`

## ?? User Interface Features

### Modern Design (v2.0) ?
- **Gradient Backgrounds**: Beautiful color gradients on buttons, badges, and cards
- **Smooth Animations**: Fade-in effects, hover animations, and transitions
- **Local Images**: Product images stored in `wwwroot/images/products/` for faster loading
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices

### Visual Enhancements
- **Product Cards**: 
  - Elevation effect on hover
  - Image zoom animation
  - Rounded corners (15px)
  - Soft shadows
  - Gradient product images
- **Buttons**: 
  - Gradient backgrounds (purple, green, pink)
  - Lift effect on hover
  - Smooth color transitions
- **Badges**: 
  - Gradient styling
  - Pulse animation on discount badges
- **Progress Bars**: 
  - Gradient fill showing discount eligibility
  - Professional appearance
- **Cards & Alerts**: 
  - Modern rounded design
  - Gradient backgrounds
  - Smooth animations

### User Experience
- Real-time quantity updates
- Confirmation dialogs for critical actions
- Success/Error messaging with TempData
- Category filtering with visual feedback
- Cart summary sidebar with calculations
- Professional color scheme with gradients
- Touch-friendly buttons and controls
