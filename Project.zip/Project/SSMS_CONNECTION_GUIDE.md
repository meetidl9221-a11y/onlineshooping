# ?? SSMS Connection Quick Reference

## ? Quick Fix - 3 Steps

### Step 1: Run Database Setup
**Double-click**: `setup-database.bat`

OR in PowerShell:
```powershell
.\setup-database.ps1
```

OR manually:
```powershell
cd C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp
dotnet ef database update
```

### Step 2: Open SSMS
Open **SQL Server Management Studio**

### Step 3: Connect with These Exact Details
```
Server type: Database Engine
Server name: (localdb)\MSSQLLocalDB
Authentication: Windows Authentication
```
**Click Connect**

---

## ?? Important Notes

### ? Correct Server Names (Case Sensitive!)
- ? `(localdb)\MSSQLLocalDB` ? Use this!
- ? `(LocalDB)\MSSQLLocalDB` ? This works too
- ? `localhost\MSSQLLocalDB` ? Wrong!
- ? `.\MSSQLLocalDB` ? Wrong!
- ? `MSSQLLocalDB` ? Wrong!

### ?? Database Location
**Database Name**: `OnlineShoppingDb`

**Physical Location** (after creation):
```
C:\Users\mmeet1\AppData\Local\Microsoft\Microsoft SQL Server Local DB\Instances\MSSQLLocalDB\
```

Files:
- `OnlineShoppingDb.mdf` (Data file)
- `OnlineShoppingDb_log.ldf` (Log file)

---

## ?? Verification Steps

### In SSMS, After Connecting:
1. Expand **Databases** folder
2. Look for **OnlineShoppingDb**
3. Expand **Tables** - you should see:
   - `dbo.CartItems`
   - `dbo.Products`
   - `dbo.__EFMigrationsHistory`

### Verify Seeded Data:
Right-click `dbo.Products` ? **Select Top 1000 Rows**

You should see **10 products**:
1. Samsung Galaxy S24 Ultra
2. Sony WH-1000XM5
3. Apple MacBook Pro 14"
4. LG 55" OLED TV
5. Canon EOS R6 Mark II
6. Nike Air Max 2024
7. Dyson V15 Detect
8. PlayStation 5
9. Fitbit Charge 6
10. Kindle Paperwhite

---

## ?? Troubleshooting

### Problem 1: Can't See Database in SSMS
**Solution**: You might not be connected to the right server.

1. In SSMS, click **Connect** ? **Database Engine**
2. Server name: `(localdb)\MSSQLLocalDB`
3. Click **Connect**
4. Refresh the **Databases** folder (F5)

### Problem 2: "Server not found"
**Solution**: LocalDB might not be running.

```cmd
sqllocaldb start MSSQLLocalDB
```

Then reconnect in SSMS.

### Problem 3: Database Doesn't Exist
**Solution**: Run the update command.

```powershell
cd C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp
dotnet ef database update
```

### Problem 4: "Cannot open database"
**Solution**: Database file might be corrupted.

```powershell
# Drop and recreate
dotnet ef database drop --force
dotnet ef database update
```

### Problem 5: LocalDB Not Installed
**Solution**: Install SQL Server Express LocalDB

Download from: https://aka.ms/ssmsfullsetup

Or install via Visual Studio Installer:
- Open Visual Studio Installer
- Modify your installation
- Individual components ? SQL Server Express LocalDB
- Install

---

## ?? Alternative: Use SQL Server Express

If LocalDB continues to cause issues:

### 1. Check if SQL Server Express is Installed
In SSMS, try connecting to:
- `.\SQLEXPRESS`
- `localhost\SQLEXPRESS`
- `YOUR_PC_NAME\SQLEXPRESS`

### 2. Update Connection String
Edit `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=.\\SQLEXPRESS;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

### 3. Run Migration
```powershell
dotnet ef database update
```

### 4. Connect in SSMS
Server name: `.\SQLEXPRESS`

---

## ?? Useful SQL Queries

After connecting to `(localdb)\MSSQLLocalDB`:

### List All Databases
```sql
SELECT name FROM sys.databases;
```

### Check Product Count
```sql
USE OnlineShoppingDb;
SELECT COUNT(*) AS TotalProducts FROM Products;
```

### View All Products
```sql
USE OnlineShoppingDb;
SELECT ProductId, Name, Price, Discount, Category FROM Products;
```

### View Products with Discounts
```sql
USE OnlineShoppingDb;
SELECT 
    Name, 
    Price, 
  Discount,
    Price - (Price * Discount / 100) AS DiscountedPrice
FROM Products
WHERE Discount > 0;
```

### Check Cart Items
```sql
USE OnlineShoppingDb;
SELECT * FROM CartItems;
```

---

## ?? Complete Reset (If Needed)

If nothing works, perform a complete reset:

### Step 1: Stop LocalDB
```cmd
sqllocaldb stop MSSQLLocalDB
```

### Step 2: Delete Instance
```cmd
sqllocaldb delete MSSQLLocalDB
```

### Step 3: Create Fresh Instance
```cmd
sqllocaldb create MSSQLLocalDB
sqllocaldb start MSSQLLocalDB
```

### Step 4: Run Setup
```powershell
cd C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp
dotnet ef database update
```

### Step 5: Connect in SSMS
Server name: `(localdb)\MSSQLLocalDB`

---

## ? Success Checklist

After setup, verify:
- [ ] LocalDB is running (`sqllocaldb info MSSQLLocalDB` shows "Running")
- [ ] Can connect to `(localdb)\MSSQLLocalDB` in SSMS
- [ ] Database `OnlineShoppingDb` appears in SSMS
- [ ] Tables `Products`, `CartItems` exist
- [ ] Products table has 10 rows
- [ ] Can query data successfully
- [ ] Application runs without errors (F5 in Visual Studio)

---

## ?? Quick Help Commands

**Check LocalDB Status:**
```cmd
sqllocaldb info MSSQLLocalDB
```

**Start LocalDB:**
```cmd
sqllocaldb start MSSQLLocalDB
```

**List All Databases in LocalDB:**
```cmd
sqlcmd -S (localdb)\MSSQLLocalDB -Q "SELECT name FROM sys.databases"
```

**Check if Your Database Exists:**
```cmd
sqlcmd -S (localdb)\MSSQLLocalDB -Q "SELECT name FROM sys.databases WHERE name='OnlineShoppingDb'"
```

**Force Database Update:**
```powershell
cd C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp
dotnet ef database update --force
```

---

## ?? Remember

**Most Common Mistake**: Using wrong server name in SSMS

? **CORRECT**: `(localdb)\MSSQLLocalDB` (with parentheses and backslash)
? **WRONG**: `localhost`, `.`, `127.0.0.1`, `MSSQLLocalDB`

---

**Need more help?** Check `DATABASE_SETUP_FIX.md` for detailed instructions.

**Last Updated**: February 2026
