# ?? Quick Setup Guide - Online Shopping Application

## Prerequisites Checklist
- [ ] Visual Studio 2022 (or later)
- [ ] .NET 8 SDK installed
- [ ] SQL Server Express LocalDB

## Step-by-Step Setup

### 1?? Open the Solution
```
1. Navigate to: C:\Users\mmeet1\Downloads\Project\
2. Double-click: OnlineShoppingApp.sln
3. Wait for Visual Studio to load
```

### 2?? Restore NuGet Packages
Visual Studio will automatically restore packages. If not:
```
Right-click on Solution ? Restore NuGet Packages
```

Or use Package Manager Console:
```powershell
dotnet restore
```

### 3?? Create the Database

#### Option A: Using Package Manager Console (Recommended)
```powershell
# Open: Tools ? NuGet Package Manager ? Package Manager Console

Update-Database
```

#### Option B: Using .NET CLI
```bash
# Open terminal in project directory
cd OnlineShoppingApp
dotnet ef database update
```

#### ? Verification
After running the migration, you should see:
- Database: `OnlineShoppingDb` created in LocalDB
- Tables: `Products`, `CartItems`
- Seeded data: 10 products automatically inserted

### 4?? Run the Application

#### Visual Studio:
```
Press F5 (or click the green "Play" button)
```

#### Command Line:
```bash
cd OnlineShoppingApp
dotnet run
```

### 5?? Access the Application
```
Browser will automatically open to:
https://localhost:7XXX/

(Port number may vary)
```

## ?? Quick Test

### Test the Discount Feature:

1. **Below Threshold (No Discount)**
 - Add "Sony Headphones" ($399.99)
   - Add "Nike Shoes" ($189.99)
   - Total: $589.98
   - ? No discount (need $4,410.02 more)

2. **Above Threshold (Discount Applied)**
   - Add "MacBook Pro" ($1,999.99)
   - Add "LG OLED TV" ($1,499.99)
   - Add "Canon Camera" ($2,499.99)
   - Total: $5,399.97
   - ? Discounts automatically applied!
   - ?? Savings: $319.97

## ?? Troubleshooting

### Issue: Database Error
**Solution:**
```powershell
# Drop and recreate database
Drop-Database
Update-Database
```

### Issue: Migration Not Found
**Solution:**
```powershell
# Ensure you're in the right directory
cd OnlineShoppingApp

# Add migration if missing
dotnet ef migrations add InitialCreate
dotnet ef database update
```

### Issue: LocalDB Not Running
**Solution:**
```cmd
# Start LocalDB
sqllocaldb start MSSQLLocalDB

# Check status
sqllocaldb info MSSQLLocalDB
```

### Issue: Port Already in Use
**Solution:**
1. Close other running applications
2. Change port in `launchSettings.json`
3. Or just restart Visual Studio

### Issue: NuGet Packages Not Restoring
**Solution:**
```powershell
# Clear NuGet cache
dotnet nuget locals all --clear

# Restore again
dotnet restore
```

## ?? Database Connection String

Default connection (already configured):
```json
"Server=(localdb)\\MSSQLLocalDB;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
```

**Features:**
- ? Windows Authentication
- ? Trust Server Certificate
- ? LocalDB instance
- ? No password required

## ?? Application Features

### Available Pages:
1. **Home** (`/`) - Landing page with welcome message
2. **Products** (`/Product/Index`) - Browse all products
3. **Product Details** (`/Product/Details/1`) - View product details
4. **Cart** (`/Cart/Index`) - View shopping cart
5. **Purchase Summary** (`/Cart/PurchaseSummary`) - Checkout page

### Key Functionality:
- ? Add products to cart
- ? Remove products from cart
- ? Update quantities
- ? Filter by category
- ? Automatic discount calculation
- ? Session-based cart storage

## ?? Seeded Products

The database includes 10 products:
1. Samsung Galaxy S24 Ultra - $1,199.99 (10% off)
2. Sony WH-1000XM5 - $399.99 (15% off)
3. Apple MacBook Pro 14" - $1,999.99 (5% off)
4. LG 55" OLED TV - $1,499.99 (20% off)
5. Canon EOS R6 Mark II - $2,499.99 (8% off)
6. Nike Air Max 2024 - $189.99 (25% off)
7. Dyson V15 Detect - $649.99 (12% off)
8. PlayStation 5 - $499.99 (0% off)
9. Fitbit Charge 6 - $159.99 (20% off)
10. Kindle Paperwhite - $139.99 (15% off)

## ?? Discount Rules

- **Threshold**: $5,000
- **Below $5,000**: No discounts applied
- **$5,000 or above**: All product discounts automatically applied
- **Visual Indicator**: Progress bar shows how close you are to the threshold

## ?? Pro Tips

1. **Browse Products**: Start at `/Product/Index`
2. **Filter by Category**: Use category buttons to filter products
3. **View Details**: Click "Details" button for product information
4. **Add Multiple Items**: Easily add items with quantity selector
5. **Track Progress**: Watch the discount eligibility progress bar
6. **Complete Purchase**: Review summary before completing order

## ?? Need Help?

### Check Logs:
```
Visual Studio ? View ? Output ? Show output from: Build
```

### Verify Database:
```powershell
# View Server Explorer
View ? Server Explorer ? Connect to LocalDB
```

### Reset Everything:
```powershell
# Delete bin and obj folders
Remove-Item -Recurse -Force bin,obj

# Restore and rebuild
dotnet restore
dotnet build

# Recreate database
Drop-Database
Update-Database
```

## ? Success Checklist

After setup, verify:
- [ ] Application runs without errors
- [ ] Products page displays 10 items
- [ ] Can add items to cart
- [ ] Cart shows correct calculations
- [ ] Discount logic works correctly
- [ ] Can complete a purchase

## ?? Learning Resources

- [ASP.NET Core MVC](https://learn.microsoft.com/en-us/aspnet/core/mvc/)
- [Entity Framework Core](https://learn.microsoft.com/en-us/ef/core/)
- [Bootstrap 5](https://getbootstrap.com/docs/5.0/)

---

**Ready to start? Open the solution and press F5!** ??
