# Features Overview

## Authentication System

### Login
- Email & password authentication
- Remember me option
- Account lockout after 5 failed attempts

### Registration
- Email, password, full name
- Automatic Customer role assignment
- Auto-login after signup

### Roles
- **Admin**: Full system access
- **Customer**: Standard user access

## Product Management

### Add Product
- Name, description, price
- Discount percentage (0-100%)
- Category selection
- Optional image URL
- Available/Unavailable toggle

### View Products
**Regular User:**
- Own products + public products only

**Admin:**
- All products from all users
- See product owner information

### Edit/Delete
- Users: Own products only
- Admin: Any product

## Shopping Cart

### Features
- Add items to cart
- Update quantities
- Remove items
- User-specific cart (per logged-in user)

### Discount System
- Threshold: $5,000
- Below $5k: No discounts
- Above $5k: All product discounts applied
- Progress bar showing status

### Checkout
- View purchase summary
- Order ID generation
- Complete purchase (clears cart)

## UI Features

### Modern Design
- Gradient backgrounds
- Smooth animations
- Responsive layout
- Bootstrap 5 components

### Product Cards
- Product image
- Name & description
- Price with discount
- Category badge
- Ownership indicator
- Action buttons

### Navigation
- Dynamic menu (auth-based)
- User dropdown
- Admin badge
- Role-specific links

## Admin Features

### Dashboard
- Total users count
- Total products count
- Quick action buttons
- System information

### Product Management
- View all user products
- Edit any product
- Delete any product
- See product owners

## Security

### Authentication
- Cookie-based auth
- 24-hour session
- Secure password hashing
- Email validation

### Authorization
- Role-based access control
- Product ownership checks
- Admin override capabilities
- Protected routes

### Password Requirements
- Minimum 6 characters
- 1 uppercase letter
- 1 lowercase letter
- 1 digit
- 1 special character

## Database

### Tables
- AspNetUsers (Identity users)
- AspNetRoles (Admin, Customer)
- Products (with UserId)
- CartItems (with UserId)

### Relationships
- User ? Products (One-to-Many)
- User ? CartItems (One-to-Many)
- Product ? User (Many-to-One)

### Seeded Data
- 1 Admin user
- 2 Roles
- 10 Public products

## Tech Stack

- **.NET 8.0**
- **ASP.NET Core MVC**
- **Entity Framework Core**
- **SQL Server LocalDB**
- **ASP.NET Identity**
- **Bootstrap 5**
- **Font Awesome**

---
All features production-ready!
