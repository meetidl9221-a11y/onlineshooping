# Online Shopping Application

ASP.NET Core MVC e-commerce application with user authentication and product management.

## Tech Stack
- .NET 8.0
- ASP.NET Core MVC
- Entity Framework Core
- SQL Server LocalDB
- ASP.NET Identity
- Bootstrap 5

## Quick Start

### Run Application
```bash
1. Open OnlineShoppingApp.sln in Visual Studio
2. Press F5
3. Login page will appear
```

### Default Credentials
**Admin Account:**
- Email: `admin@shopping.com`
- Password: `Admin@123`

### Database Setup (if needed)
```bash
cd OnlineShoppingApp
dotnet ef database update
```

## Features

### Authentication
- User registration and login
- Role-based access (Admin/Customer)
- Secure password hashing

### Product Management
- Add/Edit/Delete products
- Users see only their own products + public products
- Admin sees all products
- Category filtering

### Shopping Cart
- User-specific cart management
- Add/remove items
- Quantity management
- Discount system (on orders over $5,000)

### User Roles
**Customer:**
- Register and login
- Add personal products
- View own products + public catalog
- Manage cart and checkout

**Admin:**
- Full access to all features
- View all user products
- Admin dashboard
- User management

## Project Structure
```
OnlineShoppingApp/
??? Controllers/         # MVC Controllers
??? Models/   # Domain models and ViewModels
??? Views/              # Razor views
??? Services/     # Business logic layer
??? Data/       # Database context
??? wwwroot/      # Static files (CSS, images)
??? Migrations/         # EF Core migrations
```

## Key Features

? User authentication with ASP.NET Identity
? User-specific product management
? Role-based authorization
? Shopping cart with session management
? Discount system
? Responsive UI with Bootstrap
? Image management in wwwroot

## Development

### Add Migration
```bash
dotnet ef migrations add MigrationName
dotnet ef database update
```

### Build
```bash
dotnet build
```

### Run
```bash
dotnet run
```

## Notes
- Products with `UserId = null` are public (visible to all)
- User products are private (visible only to owner and admin)
- Cart requires authentication
- Images stored in `wwwroot/images/products/`

---
� 2026 Online Shopping Application
