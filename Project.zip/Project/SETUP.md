# Quick Setup Guide

## 1. Run the Application
```
1. Open Visual Studio 2022
2. Open OnlineShoppingApp.sln
3. Press F5
```

## 2. Login
**First time? Use admin account:**
- Email: `admin@shopping.com`
- Password: `Admin@123`

**Or create new user:**
- Click "Create Account"
- Fill registration form
- Auto-login after signup

## 3. Key Features

### Add Product
```
1. Go to Products page
2. Click "Add New Product" (green button)
3. Fill form and submit
```

### Manage Products
- **Edit**: Yellow button on your products
- **Delete**: Red button on your products
- Other users won't see your products

### Shopping Cart
```
1. Browse products
2. Click "Add to Cart"
3. Go to "My Cart"
4. Checkout
```

### Admin Features
```
Login as admin to:
- View Admin Dashboard
- See all user products
- Manage any product
- View statistics
```

## 4. Database
**Already setup?** Just run (F5)

**Need to reset?**
```bash
cd OnlineShoppingApp
dotnet ef database drop
dotnet ef database update
```

## 5. User Types

| Feature | Customer | Admin |
|---------|----------|-------|
| Add Products | ? | ? |
| Edit Own Products | ? | ? |
| Edit All Products | ? | ? |
| View All Products | ? | ? |
| Dashboard | ? | ? |

## 6. Product Visibility

**You see:**
- Your own products
- Public products (10 seeded)

**You don't see:**
- Other users' products

**Admin sees:**
- Everything!

## Troubleshooting

### Database Issues
```bash
dotnet ef database update
```

### Build Errors
```bash
dotnet clean
dotnet build
```

### Port Already in Use
- Stop other applications
- Or change port in Properties/launchSettings.json

---
That's it! Start shopping! ???
