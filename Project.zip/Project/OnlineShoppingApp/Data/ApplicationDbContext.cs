using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OnlineShoppingApp.Models;

namespace OnlineShoppingApp.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
        {
   }

        public DbSet<Product> Products { get; set; }
        public DbSet<CartItem> CartItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
      {
            base.OnModelCreating(modelBuilder);

// Configure relationships
            modelBuilder.Entity<CartItem>()
      .HasOne(c => c.User)
          .WithMany(u => u.CartItems)
      .HasForeignKey(c => c.UserId)
     .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Product>()
        .HasOne(p => p.User)
         .WithMany(u => u.Products)
  .HasForeignKey(p => p.UserId)
      .OnDelete(DeleteBehavior.SetNull);

  // Seed default admin user
var adminId = "admin-user-id-12345";
            var hasher = new PasswordHasher<ApplicationUser>();

            var adminUser = new ApplicationUser
            {
Id = adminId,
         UserName = "admin@shopping.com",
    NormalizedUserName = "ADMIN@SHOPPING.COM",
                Email = "admin@shopping.com",
     NormalizedEmail = "ADMIN@SHOPPING.COM",
        EmailConfirmed = true,
     FullName = "Admin User",
     SecurityStamp = Guid.NewGuid().ToString(),
  CreatedDate = DateTime.Now
    };
       adminUser.PasswordHash = hasher.HashPassword(adminUser, "Admin@123");

        modelBuilder.Entity<ApplicationUser>().HasData(adminUser);

     // Seed Admin role
            var adminRoleId = "admin-role-id-12345";
        modelBuilder.Entity<IdentityRole>().HasData(new IdentityRole
            {
     Id = adminRoleId,
     Name = "Admin",
      NormalizedName = "ADMIN"
            });

      // Seed Customer role
            var customerRoleId = "customer-role-id-12345";
            modelBuilder.Entity<IdentityRole>().HasData(new IdentityRole
       {
    Id = customerRoleId,
   Name = "Customer",
     NormalizedName = "CUSTOMER"
          });

    // Assign Admin role to admin user
        modelBuilder.Entity<IdentityUserRole<string>>().HasData(new IdentityUserRole<string>
         {
    RoleId = adminRoleId,
      UserId = adminId
});

            // Seed initial data with local image paths (UserId = null for default products)
  modelBuilder.Entity<Product>().HasData(
     new Product
       {
       ProductId = 1,
      UserId = null, // Default seeded product
        Name = "Samsung Galaxy S24 Ultra",
           Description = "Latest flagship smartphone with 200MP camera and S Pen",
          Price = 1199.99m,
        Discount = 10m,
      Category = "Electronics",
           ImageUrl = "/images/products/samsung-s24.jpg",
  IsAvailable = true,
           CreatedDate = DateTime.Now
     },
   new Product
        {
     ProductId = 2,
  UserId = null,
 Name = "Sony WH-1000XM5",
    Description = "Premium noise-canceling wireless headphones",
  Price = 399.99m,
        Discount = 15m,
   Category = "Electronics",
        ImageUrl = "/images/products/sony-headphones.jpg",
           IsAvailable = true,
        CreatedDate = DateTime.Now
     },
              new Product
   {
    ProductId = 3,
   UserId = null,
            Name = "Apple MacBook Pro 14\"",
         Description = "M3 chip, 16GB RAM, 512GB SSD - Professional laptop",
 Price = 1999.99m,
                    Discount = 5m,
    Category = "Computers",
    ImageUrl = "/images/products/macbook-pro.jpg",
                    IsAvailable = true,
      CreatedDate = DateTime.Now
                },
    new Product
          {
     ProductId = 4,
   UserId = null,
           Name = "LG 55\" OLED TV",
        Description = "4K OLED Smart TV with AI ThinQ and webOS",
                Price = 1499.99m,
              Discount = 20m,
            Category = "Electronics",
  ImageUrl = "/images/products/lg-oled-tv.jpg",
       IsAvailable = true,
    CreatedDate = DateTime.Now
         },
      new Product
           {
           ProductId = 5,
         UserId = null,
        Name = "Canon EOS R6 Mark II",
            Description = "Full-frame mirrorless camera with 24.2MP sensor",
        Price = 2499.99m,
         Discount = 8m,
  Category = "Cameras",
  ImageUrl = "/images/products/canon-camera.jpg",
        IsAvailable = true,
         CreatedDate = DateTime.Now
              },
                new Product
            {
               ProductId = 6,
        UserId = null,
                    Name = "Nike Air Max 2024",
           Description = "Premium running shoes with Max Air cushioning",
         Price = 189.99m,
    Discount = 25m,
          Category = "Footwear",
      ImageUrl = "/images/products/nike-shoes.jpg",
  IsAvailable = true,
 CreatedDate = DateTime.Now
         },
       new Product
    {
   ProductId = 7,
    UserId = null,
   Name = "Dyson V15 Detect",
          Description = "Cordless vacuum cleaner with laser detection",
           Price = 649.99m,
      Discount = 12m,
  Category = "Home Appliances",
           ImageUrl = "/images/products/dyson-vacuum.jpg",
            IsAvailable = true,
  CreatedDate = DateTime.Now
       },
   new Product
       {
           ProductId = 8,
          UserId = null,
        Name = "PlayStation 5",
     Description = "Next-gen gaming console with 825GB SSD",
       Price = 499.99m,
         Discount = 0m,
          Category = "Gaming",
  ImageUrl = "/images/products/playstation-5.jpg",
                IsAvailable = true,
       CreatedDate = DateTime.Now
          },
   new Product
      {
  ProductId = 9,
        UserId = null,
         Name = "Fitbit Charge 6",
              Description = "Advanced fitness tracker with GPS and heart rate monitor",
       Price = 159.99m,
      Discount = 20m,
              Category = "Wearables",
           ImageUrl = "/images/products/fitbit.jpg",
          IsAvailable = true,
 CreatedDate = DateTime.Now
    },
                new Product
 {
        ProductId = 10,
       UserId = null,
  Name = "Kindle Paperwhite",
    Description = "Waterproof e-reader with 6.8\" display and adjustable warm light",
        Price = 139.99m,
      Discount = 15m,
     Category = "Electronics",
        ImageUrl = "/images/products/kindle.jpg",
              IsAvailable = true,
        CreatedDate = DateTime.Now
      }
   );
        }
    }
}
