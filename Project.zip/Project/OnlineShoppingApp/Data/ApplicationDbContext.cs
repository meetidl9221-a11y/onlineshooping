using Microsoft.EntityFrameworkCore;
using OnlineShoppingApp.Models;

namespace OnlineShoppingApp.Data
{
    public class ApplicationDbContext : DbContext
    {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
      : base(options)
   {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<CartItem> CartItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
         base.OnModelCreating(modelBuilder);

            // Seed initial data with local image paths
       modelBuilder.Entity<Product>().HasData(
             new Product
   {
        ProductId = 1,
       Name = "Samsung Galaxy S24 Ultra",
     Description = "Latest flagship smartphone with 200MP camera and S Pen",
   Price = 1199.99m,
          Discount = 10m,
         Category = "Electronics",
        ImageUrl = "/images/products/samsung-s24.jpg",
      IsAvailable = true
       },
          new Product
  {
    ProductId = 2,
             Name = "Sony WH-1000XM5",
  Description = "Premium noise-canceling wireless headphones",
    Price = 399.99m,
        Discount = 15m,
Category = "Electronics",
           ImageUrl = "/images/products/sony-headphones.jpg",
       IsAvailable = true
          },
        new Product
         {
  ProductId = 3,
          Name = "Apple MacBook Pro 14\"",
                    Description = "M3 chip, 16GB RAM, 512GB SSD - Professional laptop",
     Price = 1999.99m,
    Discount = 5m,
             Category = "Computers",
   ImageUrl = "/images/products/macbook-pro.jpg",
        IsAvailable = true
         },
             new Product
       {
            ProductId = 4,
                    Name = "LG 55\" OLED TV",
    Description = "4K OLED Smart TV with AI ThinQ and webOS",
     Price = 1499.99m,
                    Discount = 20m,
 Category = "Electronics",
     ImageUrl = "/images/products/lg-oled-tv.jpg",
       IsAvailable = true
            },
   new Product
       {
  ProductId = 5,
   Name = "Canon EOS R6 Mark II",
     Description = "Full-frame mirrorless camera with 24.2MP sensor",
       Price = 2499.99m,
        Discount = 8m,
     Category = "Cameras",
        ImageUrl = "/images/products/canon-camera.jpg",
              IsAvailable = true
    },
            new Product
        {
       ProductId = 6,
  Name = "Nike Air Max 2024",
     Description = "Premium running shoes with Max Air cushioning",
      Price = 189.99m,
   Discount = 25m,
          Category = "Footwear",
     ImageUrl = "/images/products/nike-shoes.jpg",
     IsAvailable = true
       },
      new Product
      {
          ProductId = 7,
    Name = "Dyson V15 Detect",
       Description = "Cordless vacuum cleaner with laser detection",
   Price = 649.99m,
      Discount = 12m,
        Category = "Home Appliances",
     ImageUrl = "/images/products/dyson-vacuum.jpg",
          IsAvailable = true
 },
           new Product
                {
  ProductId = 8,
         Name = "PlayStation 5",
      Description = "Next-gen gaming console with 825GB SSD",
  Price = 499.99m,
     Discount = 0m,
      Category = "Gaming",
          ImageUrl = "/images/products/playstation-5.jpg",
         IsAvailable = true
                },
            new Product
        {
         ProductId = 9,
   Name = "Fitbit Charge 6",
        Description = "Advanced fitness tracker with GPS and heart rate monitor",
     Price = 159.99m,
         Discount = 20m,
    Category = "Wearables",
          ImageUrl = "/images/products/fitbit.jpg",
    IsAvailable = true
        },
           new Product
   {
 ProductId = 10,
         Name = "Kindle Paperwhite",
                 Description = "Waterproof e-reader with 6.8\" display and adjustable warm light",
           Price = 139.99m,
       Discount = 15m,
              Category = "Electronics",
     ImageUrl = "/images/products/kindle.jpg",
  IsAvailable = true
                }
  );
        }
    }
}
