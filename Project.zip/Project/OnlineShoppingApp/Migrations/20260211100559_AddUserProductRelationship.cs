﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OnlineShoppingApp.Migrations
{
    /// <inheritdoc />
    public partial class AddUserProductRelationship : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDate",
                table: "Products",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "Products",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user-id-12345",
                columns: new[] { "ConcurrencyStamp", "CreatedDate", "PasswordHash", "SecurityStamp" },
                values: new object[] { "1a638000-8db9-43a5-b7c8-df58ce3b2715", new DateTime(2026, 2, 11, 15, 35, 58, 613, DateTimeKind.Local).AddTicks(280), "AQAAAAIAAYagAAAAEB0JfjdLJLNOeCFWa7f4UlX8YzRLlIOwqAqDV3b31pXvYydQwTQG+/kUkk1exIQvlA==", "36a4ec67-b5ba-4822-91d0-9ef4bbfd8973" });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4391), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4395), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4399), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4402), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 5,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4404), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 6,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4407), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 7,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4409), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 8,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4412), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 9,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4414), null });

            migrationBuilder.UpdateData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 10,
                columns: new[] { "CreatedDate", "UserId" },
                values: new object[] { new DateTime(2026, 2, 11, 15, 35, 58, 672, DateTimeKind.Local).AddTicks(4417), null });

            migrationBuilder.CreateIndex(
                name: "IX_Products_UserId",
                table: "Products",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Products_AspNetUsers_UserId",
                table: "Products",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Products_AspNetUsers_UserId",
                table: "Products");

            migrationBuilder.DropIndex(
                name: "IX_Products_UserId",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "CreatedDate",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Products");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "admin-user-id-12345",
                columns: new[] { "ConcurrencyStamp", "CreatedDate", "PasswordHash", "SecurityStamp" },
                values: new object[] { "28032fd0-d7ab-4d0a-b4c3-373862034d4b", new DateTime(2026, 2, 11, 15, 23, 40, 138, DateTimeKind.Local).AddTicks(5524), "AQAAAAIAAYagAAAAEKEwYHzimQBI9+m4kP/tnmawC1PHeKgD56RVAcSrcz/YbOgAg2fXWP1wJ/kuJEoLCg==", "8d00859f-fa9b-4a10-839d-82cb1aed2b5c" });
        }
    }
}
