﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace OnlineShoppingApp.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Discount = table.Column<decimal>(type: "decimal(5,2)", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    Category = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    IsAvailable = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ProductId);
                });

            migrationBuilder.CreateTable(
                name: "CartItems",
                columns: table => new
                {
                    CartItemId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SessionId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Discount = table.Column<decimal>(type: "decimal(5,2)", nullable: false),
                    AddedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CartItems", x => x.CartItemId);
                    table.ForeignKey(
                        name: "FK_CartItems_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "ProductId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "Category", "Description", "Discount", "ImageUrl", "IsAvailable", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "Electronics", "Latest flagship smartphone with 200MP camera and S Pen", 10m, "https://via.placeholder.com/300x200?text=Samsung+S24", true, "Samsung Galaxy S24 Ultra", 1199.99m },
                    { 2, "Electronics", "Premium noise-canceling wireless headphones", 15m, "https://via.placeholder.com/300x200?text=Sony+Headphones", true, "Sony WH-1000XM5", 399.99m },
                    { 3, "Computers", "M3 chip, 16GB RAM, 512GB SSD - Professional laptop", 5m, "https://via.placeholder.com/300x200?text=MacBook+Pro", true, "Apple MacBook Pro 14\"", 1999.99m },
                    { 4, "Electronics", "4K OLED Smart TV with AI ThinQ and webOS", 20m, "https://via.placeholder.com/300x200?text=LG+OLED+TV", true, "LG 55\" OLED TV", 1499.99m },
                    { 5, "Cameras", "Full-frame mirrorless camera with 24.2MP sensor", 8m, "https://via.placeholder.com/300x200?text=Canon+Camera", true, "Canon EOS R6 Mark II", 2499.99m },
                    { 6, "Footwear", "Premium running shoes with Max Air cushioning", 25m, "https://via.placeholder.com/300x200?text=Nike+Shoes", true, "Nike Air Max 2024", 189.99m },
                    { 7, "Home Appliances", "Cordless vacuum cleaner with laser detection", 12m, "https://via.placeholder.com/300x200?text=Dyson+Vacuum", true, "Dyson V15 Detect", 649.99m },
                    { 8, "Gaming", "Next-gen gaming console with 825GB SSD", 0m, "https://via.placeholder.com/300x200?text=PlayStation+5", true, "PlayStation 5", 499.99m },
                    { 9, "Wearables", "Advanced fitness tracker with GPS and heart rate monitor", 20m, "https://via.placeholder.com/300x200?text=Fitbit", true, "Fitbit Charge 6", 159.99m },
                    { 10, "Electronics", "Waterproof e-reader with 6.8\" display and adjustable warm light", 15m, "https://via.placeholder.com/300x200?text=Kindle", true, "Kindle Paperwhite", 139.99m }
                });

            migrationBuilder.CreateIndex(
                name: "IX_CartItems_ProductId",
                table: "CartItems",
                column: "ProductId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CartItems");

            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
