using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingApp.Models;
using OnlineShoppingApp.Services;

namespace OnlineShoppingApp.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
    private readonly ICartService _cartService;
        private readonly IProductService _productService;
     private readonly UserManager<ApplicationUser> _userManager;
   private readonly ILogger<AdminController> _logger;

        public AdminController(
    ICartService cartService,
       IProductService productService,
        UserManager<ApplicationUser> userManager,
   ILogger<AdminController> logger)
        {
            _cartService = cartService;
   _productService = productService;
   _userManager = userManager;
     _logger = logger;
        }

        public async Task<IActionResult> AdminDashboard()
        {
            try
  {
          var users = _userManager.Users.ToList();
     var products = await _productService.GetAllProductsAsync();
          
          ViewBag.TotalUsers = users.Count;
  ViewBag.TotalProducts = products.Count;
           
         return View();
            }
     catch (Exception ex)
      {
                _logger.LogError(ex, "Error loading admin dashboard");
   TempData["Error"] = "Error loading dashboard.";
          return View();
   }
  }

        public async Task<IActionResult> AllCarts()
        {
  try
            {
        // This would require a new method in CartService to get all carts
      // For now, redirect to dashboard
  return RedirectToAction(nameof(AdminDashboard));
         }
    catch (Exception ex)
      {
_logger.LogError(ex, "Error loading all carts");
              TempData["Error"] = "Error loading carts.";
     return RedirectToAction(nameof(AdminDashboard));
            }
        }
    }
}
