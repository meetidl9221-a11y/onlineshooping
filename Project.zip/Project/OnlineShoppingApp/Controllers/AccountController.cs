using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingApp.Models;
using OnlineShoppingApp.Models.ViewModels;

namespace OnlineShoppingApp.Controllers
{
    public class AccountController : Controller
{
      private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
   private readonly ILogger<AccountController> _logger;

  public AccountController(
    UserManager<ApplicationUser> userManager,
    SignInManager<ApplicationUser> signInManager,
 ILogger<AccountController> logger)
   {
      _userManager = userManager;
     _signInManager = signInManager;
       _logger = logger;
        }

        [HttpGet]
  [AllowAnonymous]
      public IActionResult Login(string? returnUrl = null)
        {
     if (User.Identity?.IsAuthenticated == true)
     {
  return RedirectToAction("Index", "Product");
     }
   
 ViewData["ReturnUrl"] = returnUrl;
            return View();
  }

[HttpPost]
        [AllowAnonymous]
  [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
    {
       ViewData["ReturnUrl"] = returnUrl;
        
            if (!ModelState.IsValid)
{
     return View(model);
  }

     try
          {
       var result = await _signInManager.PasswordSignInAsync(
      model.Email, 
     model.Password, 
   model.RememberMe, 
            lockoutOnFailure: true);

       if (result.Succeeded)
 {
          _logger.LogInformation("User logged in successfully");
         
 // Check if user is admin
        var user = await _userManager.FindByEmailAsync(model.Email);
           if (user != null && await _userManager.IsInRoleAsync(user, "Admin"))
  {
return RedirectToAction("AdminDashboard", "Admin");
              }
         
        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
         {
   return Redirect(returnUrl);
            }
     
         return RedirectToAction("Index", "Product");
    }

       if (result.IsLockedOut)
       {
 _logger.LogWarning("User account locked out");
  TempData["Error"] = "Account locked due to multiple failed login attempts. Please try again later.";
  return View(model);
     }

    TempData["Error"] = "Invalid login attempt. Please check your email and password.";
      return View(model);
    }
   catch (Exception ex)
   {
    _logger.LogError(ex, "Error during login");
 TempData["Error"] = "An error occurred during login. Please try again.";
         return View(model);
 }
        }

  [HttpGet]
        [AllowAnonymous]
  public IActionResult Register(string? returnUrl = null)
   {
        if (User.Identity?.IsAuthenticated == true)
   {
       return RedirectToAction("Index", "Product");
    }
            
            ViewData["ReturnUrl"] = returnUrl;
  return View();
    }

        [HttpPost]
        [AllowAnonymous]
  [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model, string? returnUrl = null)
        {
         ViewData["ReturnUrl"] = returnUrl;

          if (!ModelState.IsValid)
 {
           return View(model);
   }

            try
        {
    var user = new ApplicationUser
   {
    UserName = model.Email,
        Email = model.Email,
     FullName = model.FullName,
     CreatedDate = DateTime.Now
 };

   var result = await _userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
        {
 // Assign Customer role by default
     await _userManager.AddToRoleAsync(user, "Customer");
     
        _logger.LogInformation("User created a new account with password");

    // Sign in the user
   await _signInManager.SignInAsync(user, isPersistent: false);
      
  TempData["Success"] = "Account created successfully! Welcome to Online Shopping!";
  
                 if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
      {
  return Redirect(returnUrl);
      }
  
    return RedirectToAction("Index", "Product");
                }

                foreach (var error in result.Errors)
    {
      ModelState.AddModelError(string.Empty, error.Description);
      }
            }
     catch (Exception ex)
            {
        _logger.LogError(ex, "Error during registration");
TempData["Error"] = "An error occurred during registration. Please try again.";
          }

       return View(model);
        }

   [HttpPost]
   [Authorize]
     [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
     try
     {
     await _signInManager.SignOutAsync();
          _logger.LogInformation("User logged out");
   TempData["Success"] = "You have been logged out successfully.";
   }
          catch (Exception ex)
     {
 _logger.LogError(ex, "Error during logout");
    TempData["Error"] = "An error occurred during logout.";
   }
            
  return RedirectToAction("Login", "Account");
        }

     [HttpGet]
        [AllowAnonymous]
  public IActionResult AccessDenied()
   {
   return View();
        }
    }
}
