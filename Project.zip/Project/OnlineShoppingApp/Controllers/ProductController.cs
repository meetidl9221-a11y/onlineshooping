using Microsoft.AspNetCore.Mvc;
using OnlineShoppingApp.Services;

namespace OnlineShoppingApp.Controllers
{
  public class ProductController : Controller
    {
        private readonly IProductService _productService;
        private readonly ILogger<ProductController> _logger;

        public ProductController(IProductService productService, ILogger<ProductController> logger)
        {
     _productService = productService;
        _logger = logger;
    }

   public async Task<IActionResult> Index(string category = "")
        {
    try
            {
   ViewBag.Categories = await _productService.GetAllCategoriesAsync();
   ViewBag.SelectedCategory = category;

   var products = string.IsNullOrEmpty(category)
                  ? await _productService.GetAllProductsAsync()
             : await _productService.GetProductsByCategoryAsync(category);

     return View(products);
            }
            catch (ApplicationException ex)
        {
    _logger.LogError(ex, "Error loading products");
          TempData["Error"] = ex.Message;
       return View(new List<OnlineShoppingApp.Models.Product>());
            }
catch (Exception ex)
   {
     _logger.LogError(ex, "Unexpected error loading products");
             TempData["Error"] = "An unexpected error occurred. Please try again later.";
            return View(new List<OnlineShoppingApp.Models.Product>());
      }
        }

        public async Task<IActionResult> Details(int id)
        {
  try
  {
                var product = await _productService.GetProductByIdAsync(id);
        if (product == null)
      {
        TempData["Error"] = "Product not found.";
      return RedirectToAction(nameof(Index));
       }

     return View(product);
            }
         catch (ApplicationException ex)
 {
       _logger.LogError(ex, "Error loading product details");
                TempData["Error"] = ex.Message;
            return RedirectToAction(nameof(Index));
   }
            catch (Exception ex)
            {
_logger.LogError(ex, "Unexpected error loading product details");
         TempData["Error"] = "An unexpected error occurred. Please try again later.";
   return RedirectToAction(nameof(Index));
     }
        }
    }
}
