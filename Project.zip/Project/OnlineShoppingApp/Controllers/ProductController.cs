using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingApp.Models;
using OnlineShoppingApp.Services;

namespace OnlineShoppingApp.Controllers
{
    [Authorize]
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<ProductController> _logger;

        public ProductController(
            IProductService productService,
            UserManager<ApplicationUser> userManager,
            ILogger<ProductController> logger)
        {
            _productService = productService;
            _userManager = userManager;
            _logger = logger;
        }

        public async Task<IActionResult> Index(string category = "")
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                var isAdmin = User.IsInRole("Admin");

                ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                ViewBag.SelectedCategory = category;
                ViewBag.IsAdmin = isAdmin;

                List<Product> products;

                if (string.IsNullOrEmpty(category))
                {
                    products = await _productService.GetProductsByUserAsync(user!.Id, isAdmin);
                }
                else
                {
                    products = await _productService.GetProductsByCategoryAsync(category);
                    // Filter by user if not admin
                    if (!isAdmin)
                    {
                        products = products.Where(p => p.UserId == user!.Id || p.UserId == null).ToList();
                    }
                }

                return View(products);
            }
            catch (ApplicationException ex)
            {
                _logger.LogError(ex, "Error loading products");
                TempData["Error"] = ex.Message;
                return View(new List<Product>());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error loading products");
                TempData["Error"] = "An unexpected error occurred. Please try again later.";
                return View(new List<Product>());
            }
        }

        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var product = await _productService.GetProductByIdAsync(id);
                if (product == null)
                {
                    TempData["Error"] = "Product not found.";
                    return RedirectToAction(nameof(Index));
                }

                return View(product);
            }
            catch (ApplicationException ex)
            {
                _logger.LogError(ex, "Error loading product details");
                TempData["Error"] = ex.Message;
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error loading product details");
                TempData["Error"] = "An unexpected error occurred. Please try again later.";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            ViewBag.Categories = await _productService.GetAllCategoriesAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                    return View(product);
                }

                var user = await _userManager.GetUserAsync(User);
                product.UserId = user!.Id;
                product.CreatedDate = DateTime.Now;
                product.IsAvailable = true;

                // Set default image if not provided
                if (string.IsNullOrEmpty(product.ImageUrl))
                {
                    product.ImageUrl = "/images/products/placeholder.svg";
                }

                await _productService.AddProductAsync(product);
                TempData["Success"] = "Product added successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (ApplicationException ex)
            {
                _logger.LogError(ex, "Error creating product");
                TempData["Error"] = ex.Message;
                ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                return View(product);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error creating product");
                TempData["Error"] = "An unexpected error occurred. Please try again later.";
                ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                return View(product);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var product = await _productService.GetProductByIdAsync(id);
                if (product == null)
                {
                    TempData["Error"] = "Product not found.";
                    return RedirectToAction(nameof(Index));
                }

                var user = await _userManager.GetUserAsync(User);
                var isAdmin = User.IsInRole("Admin");

                // Only product owner or admin can edit
                if (product.UserId != user!.Id && !isAdmin)
                {
                    TempData["Error"] = "You don't have permission to edit this product.";
                    return RedirectToAction(nameof(Index));
                }

                ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                return View(product);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading product for edit");
                TempData["Error"] = "An error occurred. Please try again.";
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            try
            {
                if (id != product.ProductId)
                {
                    return NotFound();
                }

                if (!ModelState.IsValid)
                {
                    ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                    return View(product);
                }

                var existingProduct = await _productService.GetProductByIdAsync(id);
                if (existingProduct == null)
                {
                    TempData["Error"] = "Product not found.";
                    return RedirectToAction(nameof(Index));
                }

                var user = await _userManager.GetUserAsync(User);
                var isAdmin = User.IsInRole("Admin");

                // Only product owner or admin can edit
                if (existingProduct.UserId != user!.Id && !isAdmin)
                {
                    TempData["Error"] = "You don't have permission to edit this product.";
                    return RedirectToAction(nameof(Index));
                }

                // Update properties
                existingProduct.Name = product.Name;
                existingProduct.Description = product.Description;
                existingProduct.Price = product.Price;
                existingProduct.Discount = product.Discount;
                existingProduct.Category = product.Category;
                existingProduct.IsAvailable = product.IsAvailable;

                if (!string.IsNullOrEmpty(product.ImageUrl))
                {
                    existingProduct.ImageUrl = product.ImageUrl;
                }

                await _productService.UpdateProductAsync(existingProduct);
                TempData["Success"] = "Product updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (ApplicationException ex)
            {
                _logger.LogError(ex, "Error updating product");
                TempData["Error"] = ex.Message;
                ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                return View(product);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error updating product");
                TempData["Error"] = "An unexpected error occurred. Please try again later.";
                ViewBag.Categories = await _productService.GetAllCategoriesAsync();
                return View(product);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var product = await _productService.GetProductByIdAsync(id);
                if (product == null)
                {
                    TempData["Error"] = "Product not found.";
                    return RedirectToAction(nameof(Index));
                }

                var user = await _userManager.GetUserAsync(User);
                var isAdmin = User.IsInRole("Admin");

                // Only product owner or admin can delete
                if (product.UserId != user!.Id && !isAdmin)
                {
                    TempData["Error"] = "You don't have permission to delete this product.";
                    return RedirectToAction(nameof(Index));
                }

                await _productService.DeleteProductAsync(id);
                TempData["Success"] = "Product deleted successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (ApplicationException ex)
            {
                _logger.LogError(ex, "Error deleting product");
                TempData["Error"] = ex.Message;
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error deleting product");
                TempData["Error"] = "An unexpected error occurred. Please try again later.";
                return RedirectToAction(nameof(Index));
            }
        }
    }
}
