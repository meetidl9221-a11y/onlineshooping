using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingApp.Services;

namespace OnlineShoppingApp.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
     private readonly ICartService _cartService;
        private readonly ILogger<CartController> _logger;

        public CartController(ICartService cartService, ILogger<CartController> logger)
        {
    _cartService = cartService;
       _logger = logger;
        }

private string GetUserIdentifier()
        {
            // Use User.Identity.Name (email) as identifier for authenticated users
            if (User.Identity?.IsAuthenticated == true && !string.IsNullOrEmpty(User.Identity.Name))
            {
       return User.Identity.Name;
   }
  
            // Fallback to session for guests (though they should be redirected to login)
            var sessionId = HttpContext.Session.GetString("SessionId");
     if (string.IsNullOrEmpty(sessionId))
            {
   sessionId = Guid.NewGuid().ToString();
       HttpContext.Session.SetString("SessionId", sessionId);
            }
            return sessionId;
        }

      public async Task<IActionResult> Index()
        {
            try
 {
       var userIdentifier = GetUserIdentifier();
  var cartViewModel = await _cartService.GetCartAsync(userIdentifier);
       return View(cartViewModel);
            }
            catch (ApplicationException ex)
{
     _logger.LogError(ex, "Error loading cart");
     TempData["Error"] = ex.Message;
return View(new OnlineShoppingApp.Models.ViewModels.CartViewModel());
     }
   catch (Exception ex)
          {
  _logger.LogError(ex, "Unexpected error loading cart");
          TempData["Error"] = "An unexpected error occurred. Please try again later.";
        return View(new OnlineShoppingApp.Models.ViewModels.CartViewModel());
       }
        }

   [HttpPost]
    public async Task<IActionResult> AddToCart(int productId, int quantity = 1)
        {
  try
 {
   var userIdentifier = GetUserIdentifier();
 await _cartService.AddToCartAsync(userIdentifier, productId, quantity);
      TempData["Success"] = "Product added to cart successfully!";
   }
       catch (InvalidOperationException ex)
            {
          _logger.LogWarning(ex, "Invalid operation while adding to cart");
   TempData["Error"] = ex.Message;
            }
        catch (ApplicationException ex)
      {
        _logger.LogError(ex, "Error adding product to cart");
 TempData["Error"] = ex.Message;
     }
          catch (Exception ex)
       {
  _logger.LogError(ex, "Unexpected error adding product to cart");
    TempData["Error"] = "An unexpected error occurred. Please try again later.";
 }

  return RedirectToAction("Index", "Product");
        }

        [HttpPost]
        public async Task<IActionResult> RemoveFromCart(int cartItemId)
 {
        try
       {
    var userIdentifier = GetUserIdentifier();
          await _cartService.RemoveFromCartAsync(userIdentifier, cartItemId);
        TempData["Success"] = "Product removed from cart successfully!";
            }
 catch (InvalidOperationException ex)
     {
       _logger.LogWarning(ex, "Invalid operation while removing from cart");
          TempData["Error"] = ex.Message;
   }
     catch (ApplicationException ex)
            {
        _logger.LogError(ex, "Error removing product from cart");
          TempData["Error"] = ex.Message;
 }
            catch (Exception ex)
       {
  _logger.LogError(ex, "Unexpected error removing product from cart");
     TempData["Error"] = "An unexpected error occurred. Please try again later.";
       }

            return RedirectToAction(nameof(Index));
        }

    [HttpPost]
   public async Task<IActionResult> UpdateQuantity(int cartItemId, int quantity)
        {
            try
            {
           var userIdentifier = GetUserIdentifier();
      await _cartService.UpdateCartItemQuantityAsync(userIdentifier, cartItemId, quantity);
      TempData["Success"] = "Cart updated successfully!";
          }
  catch (ArgumentException ex)
      {
       _logger.LogWarning(ex, "Invalid quantity provided");
         TempData["Error"] = ex.Message;
      }
            catch (InvalidOperationException ex)
       {
      _logger.LogWarning(ex, "Invalid operation while updating cart");
           TempData["Error"] = ex.Message;
            }
         catch (ApplicationException ex)
       {
 _logger.LogError(ex, "Error updating cart item");
       TempData["Error"] = ex.Message;
            }
            catch (Exception ex)
   {
                _logger.LogError(ex, "Unexpected error updating cart item");
      TempData["Error"] = "An unexpected error occurred. Please try again later.";
 }

     return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> PurchaseSummary()
        {
  try
     {
         var userIdentifier = GetUserIdentifier();
var summary = await _cartService.GetPurchaseSummaryAsync(userIdentifier);
       return View(summary);
          }
          catch (InvalidOperationException ex)
 {
     _logger.LogWarning(ex, "Cannot generate purchase summary");
            TempData["Error"] = ex.Message;
            return RedirectToAction(nameof(Index));
          }
    catch (ApplicationException ex)
{
        _logger.LogError(ex, "Error generating purchase summary");
                TempData["Error"] = ex.Message;
          return RedirectToAction(nameof(Index));
  }
   catch (Exception ex)
  {
       _logger.LogError(ex, "Unexpected error generating purchase summary");
   TempData["Error"] = "An unexpected error occurred. Please try again later.";
        return RedirectToAction(nameof(Index));
     }
        }

      [HttpPost]
        public async Task<IActionResult> CompletePurchase()
     {
   try
 {
       var userIdentifier = GetUserIdentifier();
         await _cartService.ClearCartAsync(userIdentifier);
                TempData["Success"] = "Thank you for your purchase! Your order has been placed successfully.";
           return RedirectToAction("Index", "Product");
            }
   catch (ApplicationException ex)
            {
           _logger.LogError(ex, "Error completing purchase");
             TempData["Error"] = ex.Message;
         return RedirectToAction(nameof(Index));
     }
        catch (Exception ex)
          {
      _logger.LogError(ex, "Unexpected error completing purchase");
             TempData["Error"] = "An unexpected error occurred. Please try again later.";
          return RedirectToAction(nameof(Index));
     }
        }
    }
}
