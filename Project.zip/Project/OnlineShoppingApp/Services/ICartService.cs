using OnlineShoppingApp.Models;
using OnlineShoppingApp.Models.ViewModels;

namespace OnlineShoppingApp.Services
{
    public interface ICartService
    {
        Task<CartViewModel> GetCartAsync(string sessionId);
   Task AddToCartAsync(string sessionId, int productId, int quantity = 1);
      Task RemoveFromCartAsync(string sessionId, int cartItemId);
     Task UpdateCartItemQuantityAsync(string sessionId, int cartItemId, int quantity);
    Task ClearCartAsync(string sessionId);
        Task<PurchaseSummaryViewModel> GetPurchaseSummaryAsync(string sessionId);
    }
}
