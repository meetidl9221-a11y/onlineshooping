using Microsoft.EntityFrameworkCore;
using OnlineShoppingApp.Data;
using OnlineShoppingApp.Models;

namespace OnlineShoppingApp.Services
{
  public class ProductService : IProductService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ProductService> _logger;

    public ProductService(ApplicationDbContext context, ILogger<ProductService> logger)
   {
 _context = context;
    _logger = logger;
   }

        public async Task<List<Product>> GetAllProductsAsync()
   {
       try
      {
return await _context.Products
  .Where(p => p.IsAvailable)
     .OrderByDescending(p => p.CreatedDate)
   .ToListAsync();
   }
   catch (Exception ex)
  {
    _logger.LogError(ex, "Error retrieving all products");
 throw new ApplicationException("Error retrieving products. Please try again.", ex);
      }
 }

        public async Task<List<Product>> GetProductsByUserAsync(string userId, bool isAdmin)
  {
    try
    {
  if (isAdmin)
    {
         // Admin sees all products
         return await _context.Products
       .Include(p => p.User)
              .Where(p => p.IsAvailable)
  .OrderByDescending(p => p.CreatedDate)
     .ToListAsync();
      }
      else
  {
   // Regular users see only their own products and seeded products (UserId == null)
            return await _context.Products
     .Where(p => p.IsAvailable && (p.UserId == userId || p.UserId == null))
              .OrderByDescending(p => p.CreatedDate)
          .ToListAsync();
    }
  }
      catch (Exception ex)
       {
      _logger.LogError(ex, "Error retrieving products for user {UserId}", userId);
      throw new ApplicationException("Error retrieving products. Please try again.", ex);
     }
  }

        public async Task<Product?> GetProductByIdAsync(int id)
 {
      try
      {
return await _context.Products
    .Include(p => p.User)
   .FirstOrDefaultAsync(p => p.ProductId == id);
     }
       catch (Exception ex)
      {
     _logger.LogError(ex, "Error retrieving product {ProductId}", id);
   throw new ApplicationException("Error retrieving product. Please try again.", ex);
 }
        }

 public async Task<List<Product>> GetProductsByCategoryAsync(string category)
    {
 try
 {
      return await _context.Products
     .Where(p => p.IsAvailable && p.Category == category)
.OrderByDescending(p => p.CreatedDate)
         .ToListAsync();
       }
  catch (Exception ex)
            {
      _logger.LogError(ex, "Error retrieving products by category {Category}", category);
  throw new ApplicationException("Error retrieving products. Please try again.", ex);
      }
  }

public async Task<List<string>> GetAllCategoriesAsync()
   {
       try
      {
       return await _context.Products
  .Where(p => p.IsAvailable && p.Category != null)
      .Select(p => p.Category!)
 .Distinct()
        .OrderBy(c => c)
    .ToListAsync();
  }
      catch (Exception ex)
            {
    _logger.LogError(ex, "Error retrieving categories");
     throw new ApplicationException("Error retrieving categories. Please try again.", ex);
     }
        }

        public async Task<Product> AddProductAsync(Product product)
        {
  try
   {
    _context.Products.Add(product);
   await _context.SaveChangesAsync();
  return product;
    }
     catch (Exception ex)
     {
    _logger.LogError(ex, "Error adding product");
    throw new ApplicationException("Error adding product. Please try again.", ex);
            }
  }

  public async Task<Product> UpdateProductAsync(Product product)
 {
       try
  {
    _context.Products.Update(product);
        await _context.SaveChangesAsync();
  return product;
 }
      catch (Exception ex)
   {
    _logger.LogError(ex, "Error updating product {ProductId}", product.ProductId);
       throw new ApplicationException("Error updating product. Please try again.", ex);
   }
   }

  public async Task<bool> DeleteProductAsync(int id)
        {
   try
   {
    var product = await _context.Products.FindAsync(id);
   if (product == null)
   {
    return false;
 }

     _context.Products.Remove(product);
   await _context.SaveChangesAsync();
      return true;
     }
catch (Exception ex)
   {
  _logger.LogError(ex, "Error deleting product {ProductId}", id);
     throw new ApplicationException("Error deleting product. Please try again.", ex);
      }
      }
    }
}
