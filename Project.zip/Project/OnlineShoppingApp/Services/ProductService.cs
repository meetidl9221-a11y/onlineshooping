using Microsoft.EntityFrameworkCore;
using OnlineShoppingApp.Data;
using OnlineShoppingApp.Models;

namespace OnlineShoppingApp.Services
{
 public class ProductService : IProductService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ProductService> _logger;

        public ProductService(ApplicationDbContext context, ILogger<ProductService> logger)
        {
  _context = context;
      _logger = logger;
        }

  public async Task<List<Product>> GetAllProductsAsync()
        {
   try
            {
        return await _context.Products
   .Where(p => p.IsAvailable)
          .OrderBy(p => p.Name)
           .ToListAsync();
 }
            catch (Exception ex)
            {
            _logger.LogError(ex, "Error retrieving all products");
                throw new ApplicationException("Error retrieving products. Please try again later.", ex);
  }
        }

        public async Task<Product?> GetProductByIdAsync(int id)
     {
   try
       {
   return await _context.Products
        .FirstOrDefaultAsync(p => p.ProductId == id && p.IsAvailable);
            }
            catch (Exception ex)
    {
       _logger.LogError(ex, "Error retrieving product with ID {ProductId}", id);
              throw new ApplicationException($"Error retrieving product. Please try again later.", ex);
     }
      }

        public async Task<List<Product>> GetProductsByCategoryAsync(string category)
        {
     try
            {
  if (string.IsNullOrEmpty(category))
 {
       return await GetAllProductsAsync();
       }

    return await _context.Products
 .Where(p => p.IsAvailable && p.Category == category)
       .OrderBy(p => p.Name)
              .ToListAsync();
     }
            catch (Exception ex)
            {
    _logger.LogError(ex, "Error retrieving products for category {Category}", category);
                throw new ApplicationException("Error retrieving products. Please try again later.", ex);
       }
        }

        public async Task<List<string>> GetAllCategoriesAsync()
   {
          try
   {
        return await _context.Products
         .Where(p => p.IsAvailable && !string.IsNullOrEmpty(p.Category))
  .Select(p => p.Category!)
     .Distinct()
   .OrderBy(c => c)
         .ToListAsync();
          }
    catch (Exception ex)
   {
    _logger.LogError(ex, "Error retrieving categories");
   throw new ApplicationException("Error retrieving categories. Please try again later.", ex);
            }
        }
  }
}
