using Microsoft.EntityFrameworkCore;
using OnlineShoppingApp.Data;
using OnlineShoppingApp.Models;
using OnlineShoppingApp.Models.ViewModels;

namespace OnlineShoppingApp.Services
{
    public class CartService : ICartService
    {
 private readonly ApplicationDbContext _context;
        private readonly ILogger<CartService> _logger;
    private const decimal DISCOUNT_THRESHOLD = 5000m;

        public CartService(ApplicationDbContext context, ILogger<CartService> logger)
        {
     _context = context;
            _logger = logger;
        }

        public async Task<CartViewModel> GetCartAsync(string sessionId)
        {
   try
   {
    var cartItems = await _context.CartItems
         .Include(c => c.Product)
    .Where(c => c.SessionId == sessionId || c.UserId == sessionId)
       .ToListAsync();

    var viewModel = CalculateCartTotals(cartItems);
return viewModel;
   }
            catch (Exception ex)
      {
      _logger.LogError(ex, "Error retrieving cart for session {SessionId}", sessionId);
 throw new ApplicationException("Error retrieving cart. Please try again.", ex);
       }
 }

   public async Task AddToCartAsync(string sessionId, int productId, int quantity = 1)
        {
  try
   {
        var product = await _context.Products.FindAsync(productId);
    if (product == null || !product.IsAvailable)
       {
           throw new InvalidOperationException("Product not found or not available.");
     }

     var existingCartItem = await _context.CartItems
      .FirstOrDefaultAsync(c => (c.SessionId == sessionId || c.UserId == sessionId) && c.ProductId == productId);

    if (existingCartItem != null)
  {
         existingCartItem.Quantity += quantity;
       _context.CartItems.Update(existingCartItem);
     }
    else
   {
  var cartItem = new CartItem
         {
         UserId = sessionId.Contains("@") ? null : sessionId, // If it's an email/userId, store as UserId
         SessionId = sessionId,
ProductId = productId,
Quantity = quantity,
    Price = product.Price,
         Discount = product.Discount,
 AddedDate = DateTime.Now
      };

            _context.CartItems.Add(cartItem);
            }

        await _context.SaveChangesAsync();
            }
      catch (InvalidOperationException)
    {
         throw;
 }
      catch (Exception ex)
 {
    _logger.LogError(ex, "Error adding product {ProductId} to cart for session {SessionId}", productId, sessionId);
   throw new ApplicationException("Error adding product to cart. Please try again.", ex);
   }
        }

        public async Task RemoveFromCartAsync(string sessionId, int cartItemId)
        {
            try
 {
              var cartItem = await _context.CartItems
       .FirstOrDefaultAsync(c => c.CartItemId == cartItemId && (c.SessionId == sessionId || c.UserId == sessionId));

    if (cartItem == null)
     {
           throw new InvalidOperationException("Cart item not found.");
      }

    _context.CartItems.Remove(cartItem);
         await _context.SaveChangesAsync();
 }
   catch (InvalidOperationException)
  {
    throw;
            }
      catch (Exception ex)
   {
 _logger.LogError(ex, "Error removing cart item {CartItemId} for session {SessionId}", cartItemId, sessionId);
    throw new ApplicationException("Error removing item from cart. Please try again.", ex);
   }
   }

        public async Task UpdateCartItemQuantityAsync(string sessionId, int cartItemId, int quantity)
        {
  try
            {
     if (quantity <= 0)
         {
       throw new ArgumentException("Quantity must be greater than 0.");
                }

     var cartItem = await _context.CartItems
      .FirstOrDefaultAsync(c => c.CartItemId == cartItemId && (c.SessionId == sessionId || c.UserId == sessionId));

                if (cartItem == null)
    {
            throw new InvalidOperationException("Cart item not found.");
 }

    cartItem.Quantity = quantity;
   _context.CartItems.Update(cartItem);
     await _context.SaveChangesAsync();
 }
       catch (ArgumentException)
  {
    throw;
            }
   catch (InvalidOperationException)
            {
 throw;
 }
   catch (Exception ex)
  {
      _logger.LogError(ex, "Error updating cart item {CartItemId} for session {SessionId}", cartItemId, sessionId);
   throw new ApplicationException("Error updating cart item. Please try again.", ex);
   }
  }

        public async Task ClearCartAsync(string sessionId)
  {
         try
   {
         var cartItems = await _context.CartItems
     .Where(c => c.SessionId == sessionId || c.UserId == sessionId)
         .ToListAsync();

    _context.CartItems.RemoveRange(cartItems);
       await _context.SaveChangesAsync();
  }
  catch (Exception ex)
   {
    _logger.LogError(ex, "Error clearing cart for session {SessionId}", sessionId);
 throw new ApplicationException("Error clearing cart. Please try again.", ex);
   }
        }

 public async Task<PurchaseSummaryViewModel> GetPurchaseSummaryAsync(string sessionId)
     {
    try
{
    var cartItems = await _context.CartItems
   .Include(c => c.Product)
       .Where(c => c.SessionId == sessionId || c.UserId == sessionId)
          .ToListAsync();

         if (!cartItems.Any())
 {
      throw new InvalidOperationException("Cart is empty.");
    }

     var subtotal = cartItems.Sum(item => item.Subtotal);
            var isDiscountApplied = subtotal >= DISCOUNT_THRESHOLD;
          var totalDiscount = isDiscountApplied ? cartItems.Sum(item => item.DiscountAmount) : 0;
    var grandTotal = isDiscountApplied ? cartItems.Sum(item => item.Total) : subtotal;

    return new PurchaseSummaryViewModel
      {
         CartItems = cartItems,
            Subtotal = subtotal,
         TotalDiscount = totalDiscount,
      GrandTotal = grandTotal,
    IsDiscountApplied = isDiscountApplied,
  DiscountThreshold = DISCOUNT_THRESHOLD,
               PurchaseDate = DateTime.Now,
      OrderId = GenerateOrderId()
    };
     }
            catch (InvalidOperationException)
   {
    throw;
    }
            catch (Exception ex)
        {
    _logger.LogError(ex, "Error generating purchase summary for session {SessionId}", sessionId);
      throw new ApplicationException("Error generating purchase summary. Please try again.", ex);
        }
     }

        private CartViewModel CalculateCartTotals(List<CartItem> cartItems)
   {
   var subtotal = cartItems.Sum(item => item.Subtotal);
    var isDiscountApplicable = subtotal >= DISCOUNT_THRESHOLD;
         var totalDiscount = isDiscountApplicable ? cartItems.Sum(item => item.DiscountAmount) : 0;
     var grandTotal = isDiscountApplicable ? cartItems.Sum(item => item.Total) : subtotal;

      var message = string.Empty;
     if (!isDiscountApplicable && cartItems.Any())
    {
 var amountNeeded = DISCOUNT_THRESHOLD - subtotal;
       message = $"Add ${amountNeeded:F2} more to your cart to get discount!";
        }
  else if (isDiscountApplicable)
    {
    message = "Congratulations! Discount applied to your order.";
            }

            return new CartViewModel
  {
             CartItems = cartItems,
       Subtotal = subtotal,
   TotalDiscount = totalDiscount,
          GrandTotal = grandTotal,
      IsDiscountApplicable = isDiscountApplicable,
    DiscountThreshold = DISCOUNT_THRESHOLD,
  Message = message
   };
 }

        private string GenerateOrderId()
        {
            return $"ORD{DateTime.Now:yyyyMMddHHmmss}{new Random().Next(1000, 9999)}";
        }
    }
}
