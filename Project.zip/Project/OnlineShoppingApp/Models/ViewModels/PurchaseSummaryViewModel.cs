namespace OnlineShoppingApp.Models.ViewModels
{
    public class PurchaseSummaryViewModel
    {
        public List<CartItem> CartItems { get; set; } = new List<CartItem>();
      public decimal Subtotal { get; set; }
   public decimal TotalDiscount { get; set; }
        public decimal GrandTotal { get; set; }
        public bool IsDiscountApplied { get; set; }
        public decimal DiscountThreshold { get; set; } = 5000;
   public DateTime PurchaseDate { get; set; } = DateTime.Now;
        public string OrderId { get; set; } = string.Empty;
    }
}
