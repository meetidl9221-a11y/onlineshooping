using System.ComponentModel.DataAnnotations;

namespace OnlineShoppingApp.Models.ViewModels
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Full name is required")]
  [StringLength(100, ErrorMessage = "Full name cannot be longer than 100 characters")]
  [Display(Name = "Full Name")]
     public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
  [EmailAddress(ErrorMessage = "Invalid email address")]
   [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password is required")]
[StringLength(100, ErrorMessage = "Password must be at least {2} characters long", MinimumLength = 6)]
     [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please confirm your password")]
   [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Password and confirmation password do not match")]
  public string ConfirmPassword { get; set; } = string.Empty;
    }
}
