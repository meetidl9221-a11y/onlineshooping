using Microsoft.AspNetCore.Identity;

namespace OnlineShoppingApp.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? FullName { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.Now;
     
  // Navigation property for cart items
        public virtual ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    
        // Navigation property for products added by user
        public virtual ICollection<Product> Products { get; set; } = new List<Product>();
    }
}
