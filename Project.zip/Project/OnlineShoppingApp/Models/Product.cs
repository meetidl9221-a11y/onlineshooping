using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineShoppingApp.Models
{
    public class Product
    {
     [Key]
      public int ProductId { get; set; }

        [Required(ErrorMessage = "Product name is required")]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        [StringLength(500)]
        public string Description { get; set; } = string.Empty;

     [Required(ErrorMessage = "Price is required")]
        [Column(TypeName = "decimal(18,2)")]
   [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0")]
    public decimal Price { get; set; }

        [Column(TypeName = "decimal(5,2)")]
    [Range(0, 100, ErrorMessage = "Discount must be between 0 and 100")]
   public decimal Discount { get; set; }

     [StringLength(200)]
 public string? ImageUrl { get; set; }

        [StringLength(50)]
        public string? Category { get; set; }

        public bool IsAvailable { get; set; } = true;

        [NotMapped]
  public decimal DiscountedPrice => Price - (Price * Discount / 100);
    }
}
