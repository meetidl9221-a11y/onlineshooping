using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineShoppingApp.Models
{
    public class CartItem
    {
        [Key]
        public int CartItemId { get; set; }

   // User ID for authenticated users (nullable for guest sessions)
  public string? UserId { get; set; }
        
        [ForeignKey("UserId")]
        public virtual ApplicationUser? User { get; set; }

        // Keep SessionId for backward compatibility and guest users
      public string? SessionId { get; set; }

        [Required]
        public int ProductId { get; set; }

   [ForeignKey("ProductId")]
        public virtual Product? Product { get; set; }

        [Required]
    [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1")]
        public int Quantity { get; set; }

        [Column(TypeName = "decimal(18,2)")]
    public decimal Price { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal Discount { get; set; }

        public DateTime AddedDate { get; set; } = DateTime.Now;

        [NotMapped]
        public decimal Subtotal => Price * Quantity;

        [NotMapped]
        public decimal DiscountAmount => (Price * Discount / 100) * Quantity;

        [NotMapped]
        public decimal Total => Subtotal - DiscountAmount;
    }
}
