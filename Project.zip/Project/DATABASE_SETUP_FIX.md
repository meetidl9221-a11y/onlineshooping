# ??? Database Setup Instructions - Fix SSMS Visibility

## Issue: Database Not Visible in SSMS

LocalDB databases are not always visible in SQL Server Management Studio (SSMS). Follow these steps to fix it.

---

## ? Solution 1: Connect to LocalDB in SSMS (Recommended)

### Step 1: Find Your LocalDB Instance Name
Open **Command Prompt** and run:
```cmd
sqllocaldb info
```

You should see: `MSSQLLocalDB`

### Step 2: Get the Instance Pipe Name
```cmd
sqllocaldb info MSSQLLocalDB
```

Copy the **Instance pipe name**, it looks like:
```
np:\\.\pipe\LOCALDB#<GUID>\tsql\query
```

### Step 3: Connect in SSMS
1. Open **SQL Server Management Studio (SSMS)**
2. Click **Connect** ? **Database Engine**
3. In **Server name**, enter one of these:
   - `(localdb)\MSSQLLocalDB`
   - OR paste the full pipe name from Step 2
4. **Authentication**: Windows Authentication
5. Click **Connect**

### Step 4: Find Your Database
Once connected, expand:
- **Databases** folder
- Look for **OnlineShoppingDb**

---

## ? Solution 2: Create Database Using Script (If Not Visible)

### Option A: Using Package Manager Console in Visual Studio

1. Open your project in **Visual Studio**
2. Go to: **Tools** ? **NuGet Package Manager** ? **Package Manager Console**
3. Run these commands:

```powershell
# Ensure you're in the correct directory
cd OnlineShoppingApp

# Remove existing migrations (if any issues)
Remove-Migration

# Create fresh migration
Add-Migration InitialCreate

# Update database
Update-Database

# Verify
Get-Migration
```

### Option B: Using .NET CLI (Command Line)

Open **Command Prompt** or **PowerShell** in your project directory:

```bash
# Navigate to project directory
cd C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp

# Remove existing migration (if recreating)
dotnet ef migrations remove --force

# Create new migration
dotnet ef migrations add InitialCreate

# Update database (this creates it)
dotnet ef database update

# List migrations
dotnet ef migrations list
```

---

## ? Solution 3: Use Full SQL Server (Best for SSMS)

If you want the database to be easily visible in SSMS, use a full SQL Server instance.

### Step 1: Update Connection String

Edit `appsettings.json`:

**For SQL Server Express:**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=.\\SQLEXPRESS;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

**For Full SQL Server:**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

**For Named Instance:**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_PC_NAME\\SQLEXPRESS;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

### Step 2: Update Database
After changing connection string:
```powershell
Update-Database
```

---

## ?? Troubleshooting Commands

### Check if LocalDB is Running
```cmd
sqllocaldb info MSSQLLocalDB
```

If **State** is **Stopped**, start it:
```cmd
sqllocaldb start MSSQLLocalDB
```

### Check Database File Location
LocalDB databases are stored here:
```
C:\Users\<YourUsername>\AppData\Local\Microsoft\Microsoft SQL Server Local DB\Instances\MSSQLLocalDB
```

### Verify Database Exists
```cmd
sqlcmd -S (localdb)\MSSQLLocalDB -Q "SELECT name FROM sys.databases"
```

You should see `OnlineShoppingDb` in the list.

### Drop and Recreate Database (If Issues)
In **Package Manager Console**:
```powershell
# Drop database
Drop-Database

# Update to recreate
Update-Database
```

Or using .NET CLI:
```bash
dotnet ef database drop --force
dotnet ef database update
```

---

## ?? Quick Fix Script

Save this as `setup-database.ps1` and run in PowerShell:

```powershell
# Navigate to project directory
Set-Location "C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp"

Write-Host "Starting Database Setup..." -ForegroundColor Green

# Check if LocalDB is running
Write-Host "Checking LocalDB status..." -ForegroundColor Yellow
sqllocaldb info MSSQLLocalDB

# Start LocalDB if not running
Write-Host "Starting LocalDB..." -ForegroundColor Yellow
sqllocaldb start MSSQLLocalDB

# Drop existing database (optional - uncomment if needed)
# Write-Host "Dropping existing database..." -ForegroundColor Yellow
# dotnet ef database drop --force

# Create migration
Write-Host "Creating migration..." -ForegroundColor Yellow
dotnet ef migrations add InitialCreate --force

# Update database
Write-Host "Updating database..." -ForegroundColor Yellow
dotnet ef database update

Write-Host "Database setup complete!" -ForegroundColor Green
Write-Host "Connect to SSMS using: (localdb)\MSSQLLocalDB" -ForegroundColor Cyan
```

---

## ?? Verify Database in SSMS

After setup, verify in SSMS:

1. **Connect** to `(localdb)\MSSQLLocalDB`
2. Expand **Databases**
3. Find **OnlineShoppingDb**
4. Expand **Tables** - you should see:
   - `dbo.Products`
   - `dbo.CartItems`
   - `dbo.__EFMigrationsHistory`

5. Right-click **Products** ? **Select Top 1000 Rows**
6. You should see **10 seeded products**

---

## ?? Common Issues & Fixes

### Issue 1: "Cannot open database"
**Solution**: Run `Update-Database` again

### Issue 2: "LocalDB not found"
**Solution**: Install SQL Server Express LocalDB:
- Download from: https://aka.ms/ssmsfullsetup

### Issue 3: "No DbContext found"
**Solution**: Make sure you're in the project directory:
```powershell
cd OnlineShoppingApp
```

### Issue 4: Migration already exists
**Solution**: 
```powershell
Remove-Migration
Add-Migration InitialCreate
Update-Database
```

### Issue 5: Cannot see in SSMS
**Solution**: Use this exact server name in SSMS:
```
(localdb)\MSSQLLocalDB
```
NOT `localhost` or `.` or `127.0.0.1`

---

## ?? Alternative: Use SQL Server Express

If LocalDB continues to cause issues:

### 1. Install SQL Server Express
Download: https://www.microsoft.com/en-us/sql-server/sql-server-downloads

### 2. Update Connection String
```json
"DefaultConnection": "Server=.\\SQLEXPRESS;Database=OnlineShoppingDb;Trusted_Connection=True;TrustServerCertificate=True;"
```

### 3. Run Migration
```powershell
Update-Database
```

### 4. Connect in SSMS
Server name: `.\SQLEXPRESS` or `localhost\SQLEXPRESS`

---

## ? Final Verification Checklist

- [ ] LocalDB is running (`sqllocaldb info MSSQLLocalDB`)
- [ ] Migration created successfully
- [ ] Database updated successfully
- [ ] Can connect to `(localdb)\MSSQLLocalDB` in SSMS
- [ ] Database `OnlineShoppingDb` is visible
- [ ] Tables `Products` and `CartItems` exist
- [ ] 10 products are seeded in Products table

---

## ?? Still Having Issues?

Run this diagnostic command:

```powershell
# Diagnostic script
sqllocaldb info MSSQLLocalDB
sqlcmd -S (localdb)\MSSQLLocalDB -Q "SELECT name FROM sys.databases WHERE name = 'OnlineShoppingDb'"
```

If database doesn't exist, run:
```powershell
cd C:\Users\mmeet1\Downloads\Project\OnlineShoppingApp
dotnet ef database update --verbose
```

The `--verbose` flag will show you exactly what's happening.

---

**Most Common Fix**: Use `(localdb)\MSSQLLocalDB` (with lowercase "localdb") as the server name in SSMS!

**Last Updated**: February 2026
