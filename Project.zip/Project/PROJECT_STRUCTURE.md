# ?? Project Structure Documentation

## Directory Tree

```
OnlineShoppingApp/
?
??? ?? Controllers/   # MVC Controllers (Handles HTTP requests)
? ??? HomeController.cs     # Landing page and general navigation
?   ??? ProductController.cs  # Product listing and details
?   ??? CartController.cs     # Shopping cart operations
?
??? ?? Services/     # Business Logic Layer
?   ??? IProductService.cs    # Product service interface
?   ??? ProductService.cs     # Product business logic implementation
?   ??? ICartService.cs       # Cart service interface
?   ??? CartService.cs        # Cart business logic implementation
?
??? ?? Models/         # Domain Models and ViewModels
?   ??? Product.cs  # Product entity model
?   ??? CartItem.cs           # Cart item entity model
?   ??? ErrorViewModel.cs     # Error handling model
?   ??? ViewModels/
?       ??? CartViewModel.cs # Cart display model
?       ??? PurchaseSummaryViewModel.cs # Purchase summary model
?
??? ?? Data/     # Database Context
?   ??? ApplicationDbContext.cs  # EF Core DbContext
?
??? ?? Migrations/      # EF Core Database Migrations
?   ??? 20260211074049_InitialCreate.cs # Initial migration
?   ??? 20260211074049_InitialCreate.Designer.cs
?   ??? ApplicationDbContextModelSnapshot.cs
?
??? ?? Views/        # Razor Views (UI)
?   ??? _ViewImports.cshtml   # Global view imports
?   ??? _ViewStart.cshtml     # View startup configuration
??
?   ??? ?? Shared/   # Shared views
?   ?   ??? _Layout.cshtml    # Master layout page
?   ?   ??? _ValidationScriptsPartial.cshtml
?   ?   ??? Error.cshtml      # Error page
?   ?
?   ??? ?? Home/        # Home views
?   ?   ??? Index.cshtml   # Landing page
?   ?   ??? Privacy.cshtml    # Privacy policy
?   ?
?   ??? ?? Product/  # Product views
?   ???? Index.cshtml      # Product listing page
?   ?   ??? Details.cshtml    # Product details page
?   ?
?   ??? ?? Cart/     # Cart views
?       ??? Index.cshtml      # Shopping cart page
?       ??? PurchaseSummary.cshtml # Checkout/summary page
?
??? ?? wwwroot/      # Static Files
?   ??? ?? css/             # Stylesheets
? ?   ??? site.css       # Custom styles
? ??? ?? js/           # JavaScript files
? ?   ??? site.js           # Custom scripts
?   ??? ?? lib/  # Third-party libraries
?   ?   ??? bootstrap/        # Bootstrap 5
?   ?   ??? jquery/           # jQuery
?   ??? favicon.ico   # Site icon
?
??? ?? obj/             # Build artifacts (ignored)
??? ?? bin/             # Compiled binaries (ignored)
?
??? ?? Program.cs       # Application entry point
??? ?? appsettings.json       # Application configuration
??? ?? appsettings.Development.json
??? ?? OnlineShoppingApp.csproj  # Project file
??? ?? .gitignore    # Git ignore rules
??? ?? README.md        # Main documentation
??? ?? SETUP_GUIDE.md         # Setup instructions
??? ?? PROJECT_STRUCTURE.md   # This file
```

## ?? File Descriptions

### Controllers Layer

#### `HomeController.cs`
- **Purpose**: Handles home page and general navigation
- **Actions**:
  - `Index()` - Landing page
  - `Privacy()` - Privacy policy page
  - `Error()` - Error handling

#### `ProductController.cs`
- **Purpose**: Manages product-related operations
- **Dependencies**: `IProductService`, `ILogger`
- **Actions**:
  - `Index(string category)` - Lists products with optional category filter
  - `Details(int id)` - Shows detailed product information
- **Error Handling**: Comprehensive try-catch with logging

#### `CartController.cs`
- **Purpose**: Handles shopping cart operations
- **Dependencies**: `ICartService`, `ILogger`
- **Session Management**: Uses session ID for cart persistence
- **Actions**:
  - `Index()` - Display cart contents
  - `AddToCart(int productId, int quantity)` - Add product to cart
  - `RemoveFromCart(int cartItemId)` - Remove item from cart
- `UpdateQuantity(int cartItemId, int quantity)` - Update item quantity
  - `PurchaseSummary()` - Display checkout summary
  - `CompletePurchase()` - Finalize and clear cart
- **Error Handling**: Multi-level exception handling

### Services Layer

#### `IProductService.cs` & `ProductService.cs`
- **Pattern**: Repository Pattern
- **Purpose**: Abstract data access for products
- **Methods**:
  - `GetAllProductsAsync()` - Retrieve all available products
  - `GetProductByIdAsync(int id)` - Get single product
  - `GetProductsByCategoryAsync(string category)` - Filter by category
  - `GetAllCategoriesAsync()` - Get distinct categories
- **Features**:
  - Async operations
  - Error logging
  - Exception handling with custom messages

#### `ICartService.cs` & `CartService.cs`
- **Pattern**: Repository Pattern
- **Purpose**: Business logic for shopping cart
- **Constants**: `DISCOUNT_THRESHOLD = 5000m`
- **Methods**:
  - `GetCartAsync(string sessionId)` - Retrieve cart with calculations
  - `AddToCartAsync(string sessionId, int productId, int quantity)` - Add items
  - `RemoveFromCartAsync(string sessionId, int cartItemId)` - Remove items
  - `UpdateCartItemQuantityAsync(string sessionId, int cartItemId, int quantity)` - Update quantities
  - `ClearCartAsync(string sessionId)` - Empty cart after purchase
  - `GetPurchaseSummaryAsync(string sessionId)` - Generate purchase summary
- **Business Logic**:
  - Automatic discount calculation
  - Threshold validation
  - Order ID generation
  - Total calculations

### Models Layer

#### `Product.cs`
- **Type**: Entity Model
- **Properties**:
  - `ProductId` (PK) - Unique identifier
  - `Name` (Required, MaxLength: 100)
  - `Description` (Required, MaxLength: 500)
  - `Price` (Required, decimal(18,2))
  - `Discount` (decimal(5,2), Range: 0-100)
  - `ImageUrl` (MaxLength: 200)
  - `Category` (MaxLength: 50)
  - `IsAvailable` (bool)
- **Computed Property**:
  - `DiscountedPrice` - Calculated final price after discount
- **Validation**: Data annotations for input validation

#### `CartItem.cs`
- **Type**: Entity Model
- **Properties**:
  - `CartItemId` (PK) - Unique identifier
  - `SessionId` (Required) - User session identifier
  - `ProductId` (FK, Required) - Reference to Product
  - `Product` (Navigation Property)
  - `Quantity` (Required, Range: 1+)
  - `Price` (decimal(18,2))
  - `Discount` (decimal(5,2))
  - `AddedDate` (DateTime)
- **Computed Properties**:
  - `Subtotal` - Price � Quantity
  - `DiscountAmount` - Calculated discount value
  - `Total` - Final amount after discount

#### `CartViewModel.cs`
- **Type**: View Model
- **Purpose**: Data transfer for cart page
- **Properties**:
  - `CartItems` - List of cart items
  - `Subtotal` - Cart subtotal
  - `TotalDiscount` - Total discount amount
  - `GrandTotal` - Final total
  - `IsDiscountApplicable` - Threshold met flag
  - `DiscountThreshold` - Minimum amount for discount
  - `Message` - User feedback message

#### `PurchaseSummaryViewModel.cs`
- **Type**: View Model
- **Purpose**: Data transfer for checkout page
- **Properties**:
  - `CartItems` - List of items
  - `Subtotal`, `TotalDiscount`, `GrandTotal`
  - `IsDiscountApplied` - Discount status
  - `DiscountThreshold` - Threshold amount
  - `PurchaseDate` - Order timestamp
  - `OrderId` - Unique order identifier

### Data Layer

#### `ApplicationDbContext.cs`
- **Type**: EF Core DbContext
- **DbSets**:
  - `Products` - Product entities
  - `CartItems` - Cart item entities
- **Seed Data**: 10 products with diverse categories
- **Configuration**: Model relationships and constraints

### Views Layer

#### Layout & Shared
- `_Layout.cshtml` - Master layout with navigation
  - Bootstrap 5 navbar
  - Font Awesome icons
  - TempData messaging
  - Footer
- `_ViewImports.cshtml` - Global usings and tag helpers
- `_ViewStart.cshtml` - Sets default layout
- `Error.cshtml` - User-friendly error page

#### Product Views
- `Index.cshtml` - Product grid with category filters
  - Responsive cards
  - Add to cart buttons
  - Category filtering
  - Product badges (discount, category)
- `Details.cshtml` - Detailed product view
  - Large image display
  - Quantity selector
  - Product information list
  - Add to cart form

#### Cart Views
- `Index.cshtml` - Shopping cart interface
  - Item list with images
  - Quantity update forms
  - Remove buttons
  - Order summary sidebar
  - Discount progress bar
  - Proceed to checkout button
- `PurchaseSummary.cshtml` - Checkout page
  - Order details table
  - Payment summary
  - Order ID and timestamp
  - Complete purchase button
  - Discount savings display

### Configuration Files

#### `Program.cs`
- **Purpose**: Application startup and configuration
- **Services Registered**:
  - Controllers with Views
  - DbContext with SQL Server
  - Scoped services (Product, Cart)
  - Distributed memory cache
  - Session middleware
- **Middleware Pipeline**:
  1. Exception handling
  2. HTTPS redirection
  3. Static files
  4. Routing
  5. Session
  6. Authorization
  7. Controller routing
- **Default Route**: `Product/Index`

#### `appsettings.json`
- **Connection Strings**:
  - DefaultConnection: LocalDB configuration
  - Windows Authentication
  - TrustServerCertificate: True
- **Logging**: Information level with ASP.NET Core warnings
- **AllowedHosts**: All hosts allowed

#### `OnlineShoppingApp.csproj`
- **Target Framework**: .NET 8.0
- **Nullable**: Enabled
- **Implicit Usings**: Enabled
- **NuGet Packages**:
  - `Microsoft.EntityFrameworkCore.SqlServer` (8.0.11)
  - `Microsoft.EntityFrameworkCore.Tools` (8.0.11)

## ??? Architecture Patterns

### 1. **MVC Pattern**
- **Model**: Domain entities and ViewModels
- **View**: Razor pages for UI
- **Controller**: Request handling and flow control

### 2. **Repository Pattern**
- Service interfaces abstract data access
- Implementation details hidden from controllers
- Easy to mock for testing

### 3. **Dependency Injection**
- Services injected via constructor
- Scoped lifetime for DbContext and services
- Testable and maintainable

### 4. **Separation of Concerns**
- Controllers: HTTP handling only
- Services: Business logic
- Models: Data structure
- Views: Presentation

## ?? Data Flow

### Product Listing Flow
```
User Request
    ?
ProductController.Index()
    ?
ProductService.GetAllProductsAsync()
    ?
ApplicationDbContext.Products
    ?
Database Query
  ?
Return List<Product>
    ?
View Rendering
 ?
HTML Response
```

### Add to Cart Flow
```
User Clicks "Add to Cart"
    ?
POST /Cart/AddToCart
    ?
CartController.AddToCart()
    ?
Get/Create Session ID
    ?
CartService.AddToCartAsync()
    ?
Check Product Availability
    ?
Create/Update CartItem
    ?
Save to Database
    ?
Redirect to Products
  ?
Show Success Message
```

### Checkout Flow
```
User Clicks "Proceed to Checkout"
 ?
GET /Cart/PurchaseSummary
    ?
CartController.PurchaseSummary()
    ?
CartService.GetPurchaseSummaryAsync()
    ?
Retrieve Cart Items
    ?
Calculate Totals (with discount logic)
    ?
Generate Order ID
    ?
Return PurchaseSummaryViewModel
    ?
Render Summary View
    ?
User Confirms
    ?
POST /Cart/CompletePurchase
    ?
Clear Cart
    ?
Redirect to Products
```

## ?? Database Schema

### Products Table
```sql
CREATE TABLE Products (
    ProductId INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    Price DECIMAL(18,2) NOT NULL,
    Discount DECIMAL(5,2) NOT NULL,
 ImageUrl NVARCHAR(200),
    Category NVARCHAR(50),
 IsAvailable BIT NOT NULL
);
```

### CartItems Table
```sql
CREATE TABLE CartItems (
    CartItemId INT PRIMARY KEY IDENTITY(1,1),
    SessionId NVARCHAR(MAX) NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL,
    Price DECIMAL(18,2) NOT NULL,
    Discount DECIMAL(5,2) NOT NULL,
    AddedDate DATETIME2 NOT NULL,
    FOREIGN KEY (ProductId) REFERENCES Products(ProductId) ON DELETE CASCADE
);
```

## ?? Key Features by File

### Error Handling
- **Controllers**: Try-catch blocks with specific exception types
- **Services**: ApplicationException with custom messages
- **Logging**: ILogger integration throughout
- **Views**: User-friendly error messages via TempData

### Session Management
- **CartController**: Session ID generation and storage
- **Configuration**: 30-minute idle timeout
- **Cookie**: HttpOnly and Essential flags

### Validation
- **Models**: Data annotation attributes
- **Client-side**: jQuery validation scripts
- **Server-side**: ModelState validation in controllers

### Security
- **HTTPS**: Enforced redirection
- **HSTS**: Enabled in production
- **CSRF**: Anti-forgery tokens in forms
- **SQL Injection**: Protected by EF Core parameterization

## ?? Dependencies

### Production Dependencies
- `Microsoft.EntityFrameworkCore.SqlServer` - Database provider
- `Microsoft.EntityFrameworkCore.Tools` - Migration tools

### Frontend Dependencies (via wwwroot/lib)
- Bootstrap 5 - UI framework
- jQuery - JavaScript library
- Font Awesome 6 - Icon library

## ?? Testing Points

### Unit Testing Targets
- Service methods (business logic)
- Model validation
- Cart calculations
- Discount logic

### Integration Testing Targets
- Controller actions
- Database operations
- Session management

### UI Testing Targets
- Product listing
- Cart operations
- Checkout flow
- Error handling

---

**Last Updated**: February 2026
**Version**: 1.0.0
**Documentation Status**: Complete
